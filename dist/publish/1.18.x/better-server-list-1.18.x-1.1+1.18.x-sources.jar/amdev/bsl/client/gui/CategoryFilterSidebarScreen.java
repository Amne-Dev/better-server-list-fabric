package amdev.bsl.client.gui;

import amdev.bsl.client.ServerMetadataStore;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2585;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public final class CategoryFilterSidebarScreen extends class_437 {
	private static final int PANEL_MARGIN = 8;
	private static final int PANEL_WIDTH = 220;
	private static final int PANEL_PADDING = 8;
	private static final int HEADER_HEIGHT = 30;
	private static final int FOOTER_HEIGHT = 56;
	private static final int ROW_HEIGHT = 20;
	private static final int ROW_GAP = 2;

	private final class_437 parent;
	private final Consumer<String> onSelect;
	private final String activeCategory;
	private final int page;

	public CategoryFilterSidebarScreen(class_437 parent, String activeCategory, Consumer<String> onSelect) {
		this(parent, activeCategory, onSelect, 0);
	}

	private CategoryFilterSidebarScreen(class_437 parent, String activeCategory, Consumer<String> onSelect, int page) {
		super(new class_2585("Category Filter"));
		this.parent = parent;
		this.onSelect = onSelect;
		this.activeCategory = activeCategory == null ? "" : activeCategory;
		this.page = Math.max(0, page);
	}

	@Override
	protected void method_25426() {
		List<String> options = this.bsl$buildOptions();
		int pageSize = this.bsl$getPageSize();
		int totalPages = Math.max(1, (options.size() + pageSize - 1) / pageSize);
		int currentPage = Math.max(0, Math.min(this.page, totalPages - 1));

		int panelLeft = this.field_22789 - PANEL_WIDTH - PANEL_MARGIN;
		int panelTop = PANEL_MARGIN;
		int panelHeight = this.field_22790 - PANEL_MARGIN * 2;
		int buttonX = panelLeft + PANEL_PADDING;
		int buttonWidth = PANEL_WIDTH - PANEL_PADDING * 2;
		int from = currentPage * pageSize;
		int to = Math.min(options.size(), from + pageSize);
		int y = panelTop + HEADER_HEIGHT;

		for (int i = from; i < to; i++) {
			String option = options.get(i);
			String label = this.bsl$formatOption(option);
			this.bsl$createSidebarButton(buttonX, y, buttonWidth, ROW_HEIGHT, label, button -> this.bsl$selectAndClose(option));
			y += ROW_HEIGHT + ROW_GAP;
		}

		int navY = panelTop + panelHeight - FOOTER_HEIGHT;
		int navWidth = (buttonWidth - PANEL_PADDING) / 2;
		class_4185 prevButton = this.bsl$createSidebarButton(buttonX, navY, navWidth, ROW_HEIGHT, "< Prev", button -> this.bsl$openPage(currentPage - 1));
		prevButton.field_22763 = currentPage > 0;

		class_4185 nextButton = this.bsl$createSidebarButton(buttonX + navWidth + PANEL_PADDING, navY, navWidth, ROW_HEIGHT, "Next >", button -> this.bsl$openPage(currentPage + 1));
		nextButton.field_22763 = currentPage < totalPages - 1;

		this.bsl$createSidebarButton(buttonX, navY + ROW_HEIGHT + 4, buttonWidth, ROW_HEIGHT, "Done", button -> this.method_25419());
	}

	@Override
	public boolean method_25422() {
		return true;
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(this.parent);
	}

	@Override
	public void method_25394(class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
		int panelLeft = this.field_22789 - PANEL_WIDTH - PANEL_MARGIN;
		int panelTop = PANEL_MARGIN;
		int panelHeight = this.field_22790 - PANEL_MARGIN * 2;

		this.parent.method_25394(poseStack, mouseX, mouseY, partialTick);
		this.method_25294(poseStack, 0, 0, this.field_22789, this.field_22790, 0x6A000000);
		this.method_25294(poseStack, panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + panelHeight, 0xD0101010);
		int listTop = panelTop + HEADER_HEIGHT - 2;
		int listBottom = panelTop + panelHeight - FOOTER_HEIGHT + 2;
		this.method_25294(poseStack, panelLeft + 2, listTop, panelLeft + PANEL_WIDTH - 2, listBottom, 0xF0101010);
		method_27534(poseStack, this.field_22793, this.field_22785, panelLeft + PANEL_WIDTH / 2, panelTop + 8, 0xFFFFFFFF);
		method_25303(poseStack, this.field_22793, "Select category", panelLeft + PANEL_PADDING, panelTop + 20, 0xFFA0A0A0);
		super.method_25394(poseStack, mouseX, mouseY, partialTick);
	}

	private void bsl$openPage(int targetPage) {
		this.field_22787.method_1507(new CategoryFilterSidebarScreen(this.parent, this.activeCategory, this.onSelect, targetPage));
	}

	private void bsl$selectAndClose(String category) {
		this.onSelect.accept(category == null ? "" : category);
		this.field_22787.method_1507(this.parent);
	}

	private class_4185 bsl$createSidebarButton(int x, int y, int width, int height, String label, class_4185.class_4241 onPress) {
		class_4185 button = new class_4185(x, y, width, height, new class_2585(label), onPress) {
			@Override
			public void method_25359(class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
				boolean hovered = this.method_25367();
				CategoryFilterSidebarScreen.this.bsl$drawSidebarButtonBackground(poseStack, this.field_22760, this.field_22761, this.field_22758, this.field_22759, this.field_22763, hovered);
				int textColor = this.field_22763 ? 0xFFFFFFFF : 0xFFA0A0A0;
				CategoryFilterSidebarScreen.this.method_25300(
					poseStack,
					CategoryFilterSidebarScreen.this.field_22793,
					label,
					this.field_22760 + this.field_22758 / 2,
					this.field_22761 + (this.field_22759 - 8) / 2,
					textColor
				);
			}
		};
		return this.method_37063(button);
	}

	private void bsl$drawSidebarButtonBackground(class_4587 poseStack, int x, int y, int width, int height, boolean active, boolean hovered) {
		if (width <= 0 || height <= 0) {
			return;
		}

		int fillColor = !active ? 0xFF56595E : (hovered ? 0xFF7A7D82 : 0xFF6A6D72);
		int topBorderColor = 0xFFD0D0D0;
		int bottomBorderColor = 0xFF4A4A4A;

		this.method_25294(poseStack, x, y, x + width, y + height, fillColor);
		this.method_25294(poseStack, x, y, x + width, y + 1, topBorderColor);
		this.method_25294(poseStack, x, y + height - 1, x + width, y + height, bottomBorderColor);
		this.method_25294(poseStack, x, y, x + 1, y + height, topBorderColor);
		this.method_25294(poseStack, x + width - 1, y, x + width, y + height, bottomBorderColor);
	}

	private List<String> bsl$buildOptions() {
		List<String> options = new ArrayList<>();
		options.add("");
		options.addAll(ServerMetadataStore.getKnownCategories());
		return options;
	}

	private int bsl$getPageSize() {
		int panelHeight = this.field_22790 - PANEL_MARGIN * 2;
		int listHeight = panelHeight - HEADER_HEIGHT - FOOTER_HEIGHT - 4;
		return Math.max(1, listHeight / (ROW_HEIGHT + ROW_GAP));
	}

	private String bsl$formatOption(String option) {
		String value = option == null || option.isEmpty() ? "All" : option;
		if (value.length() > 22) {
			value = value.substring(0, 19) + "...";
		}
		if (option == null) {
			option = "";
		}
		boolean selected = option.equalsIgnoreCase(this.activeCategory) || (option.isEmpty() && this.activeCategory.isEmpty());
		return selected ? "> " + value : value;
	}
}
