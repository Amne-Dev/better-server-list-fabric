package amdev.bsl.mixin.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
	protected TitleScreenMixin(class_2561 title) {
		super(title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void bsl$enableMultiplayerInDev(CallbackInfo ci) {
		if (!FabricLoader.getInstance().isDevelopmentEnvironment()) {
			return;
		}

		String multiplayerLabel = new class_2588("menu.multiplayer").getString();
		for (class_339 widget : this.field_22791) {
			if (!(widget instanceof class_4185 button)) {
				continue;
			}
			if (!multiplayerLabel.equals(button.method_25369().getString())) {
				continue;
			}
			button.field_22763 = true;
			break;
		}
	}
}
