package amdev.bsl.mixin.client;

import net.minecraft.class_4267;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4267.class_4270.class)
public abstract class OnlineServerEntryMixin {
}
