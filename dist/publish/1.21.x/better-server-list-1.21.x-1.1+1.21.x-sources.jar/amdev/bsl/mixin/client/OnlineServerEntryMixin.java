package amdev.bsl.mixin.client;

import amdev.bsl.client.ServerMetadataStore;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4267;
import net.minecraft.class_4280;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4267.class_4270.class)
public abstract class OnlineServerEntryMixin {
	@Shadow
	private class_642 serverData;

	@Shadow
	private class_310 minecraft;

	@Inject(method = "renderContent", at = @At("TAIL"))
	private void bsl$renderServerTags(class_332 guiGraphics, int x, int y, boolean hovered, float partialTick, CallbackInfo ci) {
		if (this.serverData == null || this.serverData.field_3761 == null) {
			return;
		}

		boolean favorite = ServerMetadataStore.isFavorite(this.serverData.field_3761);
		String category = ServerMetadataStore.getCategory(this.serverData.field_3761);
		if (!favorite && category.isBlank()) {
			return;
		}

		class_4280.class_4281<?> entry = (class_4280.class_4281<?>) (Object) this;
		int rowX = entry.method_73380();
		int rowY = entry.method_73382();
		int rowRight = entry.method_73389();

		if (favorite) {
			guiGraphics.method_51433(this.minecraft.field_1772, "★", rowX + 3, rowY + 10, 0xFFFFDD55, false);
		}

		if (!category.isBlank()) {
			String categoryLabel = '[' + this.bsl$abbreviate(category, 14) + ']';
			int labelWidth = this.minecraft.field_1772.method_1727(categoryLabel);
			int nameStartX = rowX + 35;
			int nameWidth = this.minecraft.field_1772.method_1727(this.serverData.field_3752 == null ? "" : this.serverData.field_3752);
			int preferredX = nameStartX + Math.min(nameWidth + 6, 170);
			int maxX = rowRight - 40 - labelWidth;
			if (maxX >= nameStartX + 8) {
				int labelX = Math.max(nameStartX + 8, Math.min(preferredX, maxX));
				guiGraphics.method_51433(this.minecraft.field_1772, categoryLabel, labelX, rowY + 1, 0xFFFFD070, false);
			}
		}
	}

	@Unique
	private String bsl$abbreviate(String value, int maxLength) {
		if (value.length() <= maxLength) {
			return value;
		}
		return value.substring(0, maxLength - 3) + "...";
	}
}
