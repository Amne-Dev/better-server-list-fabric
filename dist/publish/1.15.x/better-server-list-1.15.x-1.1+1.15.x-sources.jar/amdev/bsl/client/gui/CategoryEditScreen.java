package amdev.bsl.client.gui;

import java.util.function.Consumer;
import net.minecraft.class_2585;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CategoryEditScreen extends class_437 {
	private final class_437 parent;
	private final Consumer<String> onSave;
	private final String initialValue;
	private class_342 categoryField;

	public CategoryEditScreen(class_437 parent, String initialValue, Consumer<String> onSave) {
		super(new class_2585("Edit Category"));
		this.parent = parent;
		this.initialValue = initialValue == null ? "" : initialValue;
		this.onSave = onSave;
	}

	@Override
	protected void init() {
		int fieldWidth = Math.min(320, this.width - 40);
		int centerX = this.width / 2;
		int centerY = this.height / 2;

		this.categoryField = this.addButton(new class_342(this.font, centerX - fieldWidth / 2, centerY - 10, fieldWidth, 20, "Category"));
		this.categoryField.method_1880(32);
		this.categoryField.method_1852(this.initialValue);
		this.categoryField.method_1876(true);

		this.addButton(new class_4185(centerX - 155, centerY + 22, 100, 20, "Save", button -> this.bsl$saveAndClose()));
		this.addButton(new class_4185(centerX - 50, centerY + 22, 100, 20, "Clear", button -> this.bsl$clearAndClose()));
		this.addButton(new class_4185(centerX + 55, centerY + 22, 100, 20, "Cancel", button -> this.minecraft.method_1507(this.parent)));
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return true;
	}

	@Override
	public void onClose() {
		this.minecraft.method_1507(this.parent);
	}

	@Override
	public void render(int mouseX, int mouseY, float partialTick) {
		this.fill(0, 0, this.width, this.height, 0xB0101010);
		drawCenteredString(this.font, this.title.getString(), this.width / 2, this.height / 2 - 34, 0xFFFFFFFF);
		drawCenteredString(this.font, "Type any custom category name", this.width / 2, this.height / 2 - 22, 0xFFA0A0A0);
		super.render(mouseX, mouseY, partialTick);
	}

	private void bsl$saveAndClose() {
		this.onSave.accept(this.categoryField.method_1882().trim());
		this.minecraft.method_1507(this.parent);
	}

	private void bsl$clearAndClose() {
		this.onSave.accept("");
		this.minecraft.method_1507(this.parent);
	}
}
