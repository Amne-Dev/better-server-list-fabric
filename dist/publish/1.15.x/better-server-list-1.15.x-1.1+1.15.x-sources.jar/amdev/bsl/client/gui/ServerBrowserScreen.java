package amdev.bsl.client.gui;

import amdev.bsl.client.PublicServerCatalog;
import amdev.bsl.client.ServerMetadataStore;
import amdev.bsl.client.ServerOrdering;
import amdev.bsl.mixin.client.JoinMultiplayerScreenInvoker;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2585;
import net.minecraft.class_2960;
import net.minecraft.class_342;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;

public final class ServerBrowserScreen extends class_437 {
	private static final int PAGE_SIZE = 8;
	private static final int ROW_HEIGHT = 36;
	private static final String MCSRSTAT_ICON_PREFIX = "https://api.mcsrvstat.us/icon/";
	private static final String MCSRSTAT_ICON_PREFIX_HTTP = "http://api.mcsrvstat.us/icon/";
	private static final String MINE_SPARK_STATUS_TEMPLATE = "https://srvstat.minespark.org/general/%s";
	private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
		.followRedirects(HttpClient.Redirect.NORMAL)
		.connectTimeout(Duration.ofSeconds(8))
		.build();

	private final class_500 parent;
	private final List<PublicServerCatalog.Entry> allEntries = new ArrayList<>();
	private final List<PublicServerCatalog.Entry> filteredEntries = new ArrayList<>();
	private final List<class_4185> resultButtons = new ArrayList<>();
	private final Map<String, class_2960> logoTextures = new HashMap<>();
	private final Set<String> logoLoading = new HashSet<>();
	private final List<class_2960> registeredTextures = new ArrayList<>();
	private class_342 searchField;
	private class_4185 previousPageButton;
	private class_4185 nextPageButton;
	private class_4185 addButton;
	private class_4185 openWebsiteButton;
	private class_4185 refreshApiButton;
	private PublicServerCatalog.Entry selected;
	private int currentPage;
	private String statusMessage = "";
	private int buttonX;
	private int buttonWidth;
	private int listTop;
	private class_1799 loadingIcon;
	private long nextLoadingIconRetryAt;
	private boolean loadingLive;
	private CompletableFuture<PublicServerCatalog.LoadResult> liveLoadFuture;

	public ServerBrowserScreen(class_500 parent) {
		super(new class_2585("Find Servers"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		this.bsl$cancelLiveLoad();
		this.allEntries.clear();
		this.filteredEntries.clear();
		this.selected = null;
		this.currentPage = 0;
		this.loadingIcon = class_1799.field_8037;
		this.nextLoadingIconRetryAt = 0L;

		this.listTop = 46;
		this.buttonWidth = Math.min(this.width - 20, Math.max(575, this.width - 40));
		this.buttonX = (this.width - this.buttonWidth) / 2;

		this.searchField = this.addButton(new class_342(this.font, this.buttonX, 18, this.buttonWidth, 20, "Search public servers"));
		this.searchField.method_1887("Search name, address, category, tags");
		this.searchField.method_1863(value -> {
			this.currentPage = 0;
			this.bsl$refreshFilteredEntries();
		});

		this.resultButtons.clear();
		for (int i = 0; i < PAGE_SIZE; i++) {
			final int slot = i;
			class_4185 button = this.addButton(this.bsl$createRowHitbox(
				this.buttonX,
				this.listTop + i * ROW_HEIGHT,
				this.buttonWidth,
				ROW_HEIGHT - 2,
				b -> this.bsl$selectFromSlot(slot)
			));
			this.resultButtons.add(button);
		}

		int controlsY = this.height - 54;
		int prevX = this.buttonX;
		int nextX = prevX + 80;
		int addX = nextX + 80;
		int websiteX = addX + 115;
		int reloadX = websiteX + 115;
		int doneX = this.buttonX + this.buttonWidth - 75;

		this.previousPageButton = this.addButton(new class_4185(prevX, controlsY, 75, 20, "< Prev", b -> this.bsl$changePage(-1)));
		this.nextPageButton = this.addButton(new class_4185(nextX, controlsY, 75, 20, "Next >", b -> this.bsl$changePage(1)));
		this.addButton = this.addButton(new class_4185(addX, controlsY, 110, 20, "Add Selected", b -> this.bsl$addSelectedServer()));
		this.openWebsiteButton = this.addButton(new class_4185(websiteX, controlsY, 110, 20, "Open Website", b -> this.bsl$openSelectedWebsite()));
		this.refreshApiButton = this.addButton(new class_4185(reloadX, controlsY, 100, 20, "Reload API", b -> this.bsl$loadLiveCatalog(true)));
		this.addButton(new class_4185(doneX, controlsY, 75, 20, "Done", b -> this.minecraft.method_1507(this.parent)));

		this.loadingLive = true;
		this.statusMessage = "Loading live server catalog...";
		this.bsl$refreshFilteredEntries();
		this.bsl$loadLiveCatalog(false);
	}

	@Override
	public void onClose() {
		this.bsl$cancelLiveLoad();
		this.bsl$releaseLogoTextures();
		this.minecraft.method_1507(this.parent);
	}

	@Override
	public void render(int mouseX, int mouseY, float partialTick) {
		this.fill(0, 0, this.width, this.height, 0xB0101010);
		super.render(mouseX, mouseY, partialTick);

		drawCenteredString(this.font, this.title.getString(), this.width / 2, 6, 0xFFFFFFFF);
		drawString(this.font, "Results: " + this.filteredEntries.size(), 10, this.height - 76, 0xFFA0A0A0);
		if (!this.statusMessage.isEmpty()) {
			drawString(this.font, this.statusMessage, 10, this.height - 66, 0xFF80FF80);
		}

		if (this.loadingLive) {
			this.bsl$renderLoadingIndicator();
		} else {
			this.bsl$renderRows();
		}
	}

	private void bsl$renderRows() {
		int pageStart = this.currentPage * PAGE_SIZE;
		for (int i = 0; i < PAGE_SIZE; i++) {
			int index = pageStart + i;
			if (index < 0 || index >= this.filteredEntries.size()) {
				continue;
			}

			PublicServerCatalog.Entry entry = this.filteredEntries.get(index);
			int rowX = this.buttonX;
			int rowY = this.listTop + i * ROW_HEIGHT;

			if (entry.equals(this.selected)) {
				this.fill(rowX - 1, rowY - 1, rowX + this.buttonWidth + 1, rowY + ROW_HEIGHT - 1, 0x40FFD67A);
				this.fill(rowX - 1, rowY - 1, rowX + this.buttonWidth + 1, rowY, 0xFFFFD67A);
				this.fill(rowX - 1, rowY + ROW_HEIGHT - 2, rowX + this.buttonWidth + 1, rowY + ROW_HEIGHT - 1, 0xFFFFD67A);
			}

			this.bsl$ensureLogoTexture(entry);
			this.bsl$drawLogo(entry, rowX + 6, rowY + 8);
			drawString(this.font, this.bsl$abbreviate(entry.name(), 38), rowX + 28, rowY + 6, 0xFFFFFFFF);
			drawString(this.font, this.bsl$abbreviate(entry.address(), 45), rowX + 28, rowY + 18, 0xFF9FA7B0);

			String playersText = this.bsl$playersText(entry);
			int playersColor = entry.players() > 0 ? 0xFF9DE27A : 0xFFA0A0A0;
			drawString(this.font, playersText, rowX + this.buttonWidth - 120, rowY + 12, playersColor);
		}
	}

	private void bsl$renderLoadingIndicator() {
		float wave = (float) Math.sin((class_156.method_658() % 1600L) / 1600.0 * Math.PI * 2.0);
		float pulse = (wave + 1.0f) * 0.5f;
		int iconX = this.width / 2 - 8;
		int iconY = this.listTop + PAGE_SIZE * ROW_HEIGHT / 2 - 8;

		class_1799 icon = this.bsl$getLoadingIcon();
		if (!icon.method_7960()) {
			this.itemRenderer.method_4023(icon, iconX, iconY);
		} else {
			this.bsl$renderFallbackIcon(iconX, iconY, true);
		}

		int darkAlpha = ((int) ((1.0f - pulse) * 120.0f)) << 24;
		int lightAlpha = ((int) (pulse * 70.0f)) << 24;
		this.fill(iconX, iconY, iconX + 16, iconY + 16, darkAlpha);
		this.fill(iconX, iconY, iconX + 16, iconY + 16, lightAlpha | 0x00FFFFFF);

		int textAlpha = ((int) (140 + pulse * 115.0f)) << 24;
		drawCenteredString(this.font, "Loading...", this.width / 2, iconY + 24, textAlpha | 0xD8C8FF);
	}

	private void bsl$drawLogo(PublicServerCatalog.Entry entry, int x, int y) {
		String key = this.bsl$logoKey(entry.address());
		class_2960 textureId = this.logoTextures.get(key);
		if (textureId != null) {
			this.minecraft.method_1531().method_22813(textureId);
			this.blit(x, y, 0, 0, 16, 16, 16, 16);
			return;
		}

		class_1799 icon = this.bsl$getLoadingIcon();
		if (!icon.method_7960()) {
			this.itemRenderer.method_4023(icon, x, y);
		} else {
			this.bsl$renderFallbackIcon(x, y, false);
		}
	}

	private class_1799 bsl$getLoadingIcon() {
		if (this.loadingIcon != null && !this.loadingIcon.method_7960()) {
			return this.loadingIcon;
		}

		long now = class_156.method_658();
		if (now < this.nextLoadingIconRetryAt) {
			return class_1799.field_8037;
		}

		try {
			this.loadingIcon = new class_1799(class_1802.field_8137);
			return this.loadingIcon;
		} catch (Exception ignored) {
			this.nextLoadingIconRetryAt = now + 1000L;
			return class_1799.field_8037;
		}
	}

	private void bsl$renderFallbackIcon(int x, int y, boolean loading) {
		int fillColor = loading ? 0xFF6C5D92 : 0xFF4B4F57;
		int borderColor = loading ? 0xFFD8C8FF : 0xFF9AA0AA;
		this.fill(x, y, x + 16, y + 16, fillColor);
		this.fill(x, y, x + 16, y + 1, borderColor);
		this.fill(x, y + 15, x + 16, y + 16, borderColor);
		this.fill(x, y, x + 1, y + 16, borderColor);
		this.fill(x + 15, y, x + 16, y + 16, borderColor);
	}

	private void bsl$refreshFilteredEntries() {
		String query = this.searchField == null ? "" : this.searchField.method_1882().trim().toLowerCase(Locale.ROOT);

		this.filteredEntries.clear();
		for (PublicServerCatalog.Entry entry : this.allEntries) {
			if (this.bsl$matchesQuery(entry, query)) {
				this.filteredEntries.add(entry);
			}
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		if (this.currentPage > maxPage) {
			this.currentPage = maxPage;
		}
		if (this.selected != null && !this.filteredEntries.contains(this.selected)) {
			this.selected = null;
		}

		this.bsl$refreshResultButtons();
		this.bsl$refreshActionButtons();
	}

	private void bsl$loadLiveCatalog(boolean forceRefresh) {
		this.bsl$cancelLiveLoad();

		if (!forceRefresh) {
			PublicServerCatalog.LoadResult cached = PublicServerCatalog.getSessionCachedResult();
			if (cached != null) {
				this.loadingLive = false;
				this.statusMessage = cached.fromLiveApi()
					? "Loaded " + cached.entries().size() + " servers from session cache."
					: "Using cached bundled catalog from this session.";
				this.allEntries.clear();
				this.allEntries.addAll(cached.entries());
				this.filteredEntries.clear();
				this.selected = null;
				this.currentPage = 0;
				this.bsl$refreshFilteredEntries();
				return;
			}
		}

		if (this.refreshApiButton != null) {
			this.refreshApiButton.active = false;
		}
		this.loadingLive = true;
		this.statusMessage = forceRefresh ? "Reloading live server catalog..." : "Loading live server catalog...";
		this.allEntries.clear();
		this.filteredEntries.clear();
		this.selected = null;
		this.currentPage = 0;
		this.bsl$refreshFilteredEntries();

		this.liveLoadFuture = forceRefresh
			? PublicServerCatalog.reloadPreferredAsync(this.minecraft.method_1478())
			: PublicServerCatalog.loadPreferredAsync(this.minecraft.method_1478());
		this.liveLoadFuture.whenComplete((result, throwable) -> this.minecraft.execute(() -> {
			if (this.minecraft == null || this.minecraft.field_1755 != this) {
				return;
			}

			this.loadingLive = false;
			if (this.refreshApiButton != null) {
				this.refreshApiButton.active = true;
			}

			PublicServerCatalog.LoadResult safeResult;
			if (throwable != null || result == null || result.entries() == null) {
				safeResult = new PublicServerCatalog.LoadResult(PublicServerCatalog.loadBundled(this.minecraft.method_1478()), false);
				this.statusMessage = "Live API unavailable. Showing bundled catalog.";
			} else {
				safeResult = result;
				if (safeResult.fromLiveApi()) {
					this.statusMessage = "Loaded " + safeResult.entries().size() + " servers from live API.";
				} else {
					this.statusMessage = "Live API unavailable. Showing bundled catalog.";
				}
			}

			this.allEntries.clear();
			this.allEntries.addAll(safeResult.entries());
			this.currentPage = 0;
			this.selected = null;
			this.bsl$refreshFilteredEntries();
		}));
	}

	private void bsl$cancelLiveLoad() {
		if (this.liveLoadFuture != null) {
			this.liveLoadFuture.cancel(true);
			this.liveLoadFuture = null;
		}
	}

	private void bsl$refreshResultButtons() {
		if (this.loadingLive) {
			for (class_4185 button : this.resultButtons) {
				button.visible = false;
				button.active = false;
			}
			return;
		}

		int pageStart = this.currentPage * PAGE_SIZE;
		for (int i = 0; i < this.resultButtons.size(); i++) {
			class_4185 button = this.resultButtons.get(i);
			int index = pageStart + i;
			if (index < this.filteredEntries.size()) {
				button.visible = true;
				button.active = true;
				button.setMessage("");
			} else {
				button.visible = false;
				button.active = false;
			}
		}
	}

	private void bsl$refreshActionButtons() {
		if (this.loadingLive) {
			this.previousPageButton.active = false;
			this.nextPageButton.active = false;
			this.addButton.active = false;
			this.openWebsiteButton.active = false;
			return;
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		this.previousPageButton.active = this.currentPage > 0;
		this.nextPageButton.active = this.currentPage < maxPage;

		if (this.selected == null) {
			this.addButton.active = false;
			this.openWebsiteButton.active = false;
			return;
		}

		this.addButton.active = true;
		this.openWebsiteButton.active = !this.selected.website().isEmpty();
	}

	private void bsl$selectFromSlot(int slot) {
		if (this.loadingLive) {
			return;
		}

		int index = this.currentPage * PAGE_SIZE + slot;
		if (index < 0 || index >= this.filteredEntries.size()) {
			return;
		}
		this.selected = this.filteredEntries.get(index);
		this.statusMessage = "";
		this.bsl$refreshActionButtons();
	}

	private void bsl$changePage(int delta) {
		if (this.loadingLive) {
			return;
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		this.currentPage = Math.max(0, Math.min(maxPage, this.currentPage + delta));
		this.bsl$refreshResultButtons();
		this.bsl$refreshActionButtons();
	}

	private void bsl$addSelectedServer() {
		if (this.selected == null) {
			return;
		}

		class_641 serverList = this.parent.method_2529();
		if (this.bsl$containsServer(serverList, this.selected.address())) {
			this.statusMessage = "Server already exists in your list.";
			return;
		}

		class_642 serverData = new class_642(this.selected.name(), this.selected.address(), false);
		serverList.method_2988(serverData);
		if (ServerMetadataStore.getCategory(serverData.field_3761).isEmpty() && !this.selected.category().isEmpty()) {
			ServerMetadataStore.setCategory(serverData.field_3761, this.selected.category());
		}
		ServerOrdering.reorder(serverList);
		serverList.method_2987();
		((JoinMultiplayerScreenInvoker) this.parent).bsl$refreshServerList();

		this.statusMessage = "Added " + this.selected.name() + ".";
	}

	private void bsl$openSelectedWebsite() {
		if (this.selected == null || this.selected.website().isEmpty()) {
			return;
		}

		this.minecraft.method_1507(new class_407(open -> {
			if (open) {
				class_156.method_668().method_670(this.selected.website());
			}
			this.minecraft.method_1507(this);
		}, this.selected.website(), true));
	}

	private void bsl$ensureLogoTexture(PublicServerCatalog.Entry entry) {
		if (entry.logoUrl().isBlank()) {
			return;
		}

		String key = this.bsl$logoKey(entry.address());
		if (this.logoTextures.containsKey(key) || this.logoLoading.contains(key)) {
			return;
		}

		this.logoLoading.add(key);
		CompletableFuture
			.supplyAsync(() -> this.bsl$downloadLogo(entry.logoUrl()))
			.whenComplete((image, throwable) -> this.minecraft.execute(() -> {
				this.logoLoading.remove(key);
				if (throwable != null || image == null) {
					return;
				}

				try {
					class_2960 textureId = new class_2960("better-server-list", "server_logo/" + Integer.toUnsignedString(key.hashCode()));
					class_1043 texture = new class_1043(image);
					texture.method_4524();
					this.minecraft.method_1531().method_4616(textureId, texture);
					this.logoTextures.put(key, textureId);
					this.registeredTextures.add(textureId);
				} catch (Exception exception) {
					image.close();
				}
			}));
	}

	private class_1011 bsl$downloadLogo(String logoUrl) {
		try {
			class_1011 directDataImage = this.bsl$decodeDataImage(logoUrl);
			if (directDataImage != null) {
				return directDataImage;
			}

			String mcsAddress = this.bsl$extractMcsrvstatAddress(logoUrl);
			if (!mcsAddress.isEmpty()) {
				class_1011 fallbackStatusIcon = this.bsl$downloadMinesparkStatusIcon(mcsAddress);
				if (fallbackStatusIcon != null) {
					return fallbackStatusIcon;
				}
			}

			HttpRequest request = HttpRequest.newBuilder()
				.GET()
				.uri(URI.create(logoUrl))
				.timeout(Duration.ofSeconds(8))
				.header("Accept", "image/png,image/*")
				.header("User-Agent", "better-server-list-fabric/1.1")
				.build();
			HttpResponse<byte[]> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofByteArray());
			if (response.statusCode() < 200 || response.statusCode() >= 300) {
				return null;
			}
			return class_1011.method_4309(new ByteArrayInputStream(response.body()));
		} catch (Exception exception) {
			return null;
		}
	}

	private class_1011 bsl$downloadMinesparkStatusIcon(String address) {
		try {
			String encodedAddress = URLEncoder.encode(address, StandardCharsets.UTF_8);
			String endpoint = String.format(MINE_SPARK_STATUS_TEMPLATE, encodedAddress);
			HttpRequest request = HttpRequest.newBuilder()
				.GET()
				.uri(URI.create(endpoint))
				.timeout(Duration.ofSeconds(8))
				.header("Accept", "application/json")
				.header("User-Agent", "better-server-list-fabric/1.1")
				.build();
			HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
			if (response.statusCode() < 200 || response.statusCode() >= 300) {
				return null;
			}

			JsonElement parsed = new JsonParser().parse(response.body());
			if (!parsed.isJsonObject()) {
				return null;
			}

			JsonObject object = parsed.getAsJsonObject();
			JsonElement iconElement = object.get("icon");
			if (iconElement == null || !iconElement.isJsonPrimitive()) {
				return null;
			}

			return this.bsl$decodeDataImage(iconElement.getAsString());
		} catch (Exception ignored) {
			return null;
		}
	}

	private class_1011 bsl$decodeDataImage(String dataUrl) {
		if (dataUrl == null || !dataUrl.startsWith("data:image/")) {
			return null;
		}

		int commaIndex = dataUrl.indexOf(',');
		if (commaIndex <= 0 || commaIndex >= dataUrl.length() - 1) {
			return null;
		}

		String payload = dataUrl.substring(commaIndex + 1).trim();
		if (payload.contains("%")) {
			try {
				payload = java.net.URLDecoder.decode(payload, StandardCharsets.UTF_8);
			} catch (Exception ignored) {
				// Keep original payload and try decode paths below.
			}
		}

		byte[] decoded = this.bsl$tryBase64Decode(payload);
		if (decoded == null || decoded.length == 0) {
			return null;
		}

		try {
			return class_1011.method_4309(new ByteArrayInputStream(decoded));
		} catch (Exception ignored) {
			return null;
		}
	}

	private byte[] bsl$tryBase64Decode(String payload) {
		try {
			return Base64.getDecoder().decode(payload);
		} catch (Exception ignored) {
		}
		try {
			return Base64.getMimeDecoder().decode(payload);
		} catch (Exception ignored) {
		}
		try {
			return Base64.getUrlDecoder().decode(payload);
		} catch (Exception ignored) {
		}
		return null;
	}

	private String bsl$extractMcsrvstatAddress(String logoUrl) {
		if (logoUrl == null || logoUrl.isEmpty()) {
			return "";
		}
		String normalized = logoUrl;
		if (normalized.startsWith(MCSRSTAT_ICON_PREFIX)) {
			normalized = normalized.substring(MCSRSTAT_ICON_PREFIX.length());
		} else if (normalized.startsWith(MCSRSTAT_ICON_PREFIX_HTTP)) {
			normalized = normalized.substring(MCSRSTAT_ICON_PREFIX_HTTP.length());
		} else {
			return "";
		}

		int queryIndex = normalized.indexOf('?');
		if (queryIndex >= 0) {
			normalized = normalized.substring(0, queryIndex);
		}
		return normalized.trim();
	}

	private void bsl$releaseLogoTextures() {
		if (this.minecraft == null) {
			return;
		}
		for (class_2960 textureId : this.registeredTextures) {
			this.minecraft.method_1531().method_4615(textureId);
		}
		this.registeredTextures.clear();
		this.logoTextures.clear();
		this.logoLoading.clear();
	}

	private boolean bsl$containsServer(class_641 serverList, String address) {
		if (serverList == null || address == null || address.trim().isEmpty()) {
			return false;
		}
		String normalized = address.trim().toLowerCase(Locale.ROOT);
		for (int i = 0; i < serverList.method_2984(); i++) {
			class_642 existing = serverList.method_2982(i);
			if (existing != null && existing.field_3761 != null && normalized.equals(existing.field_3761.trim().toLowerCase(Locale.ROOT))) {
				return true;
			}
		}
		return false;
	}

	private boolean bsl$matchesQuery(PublicServerCatalog.Entry entry, String query) {
		if (query.isEmpty()) {
			return true;
		}

		String searchable = entry.searchableText().toLowerCase(Locale.ROOT);
		String[] terms = query.split("\\s+");
		for (String term : terms) {
			if (!term.isEmpty() && !searchable.contains(term)) {
				return false;
			}
		}
		return true;
	}

	private String bsl$playersText(PublicServerCatalog.Entry entry) {
		if (entry.players() >= 0 && entry.maxPlayers() > 0) {
			return "Players: " + entry.players() + "/" + entry.maxPlayers();
		}
		if (entry.players() >= 0) {
			return "Players: " + entry.players();
		}
		return "Players: --";
	}

	private String bsl$abbreviate(String value, int maxLength) {
		if (value.length() <= maxLength) {
			return value;
		}
		return value.substring(0, maxLength - 3) + "...";
	}

	private String bsl$logoKey(String address) {
		return address == null ? "" : address.trim().toLowerCase(Locale.ROOT);
	}

	private class_4185 bsl$createRowHitbox(int x, int y, int width, int height, class_4185.class_4241 onPress) {
		return new class_4185(x, y, width, height, "", onPress) {
			@Override
			public void renderButton(int mouseX, int mouseY, float partialTick) {
				ServerBrowserScreen.this.bsl$drawWideButtonBackground(this.x, this.y, this.width, this.height, this.active, this.isHovered());
			}
		};
	}

	private void bsl$drawWideButtonBackground(int x, int y, int width, int height, boolean active, boolean hovered) {
		if (width <= 0 || height <= 0) {
			return;
		}

		int fillColor = !active ? 0xFF4A4D52 : (hovered ? 0xFF7A7D82 : 0xFF676A6F);
		int topBorderColor = hovered ? 0xFFD9DDE3 : 0xFFC4C8CF;
		int bottomBorderColor = hovered ? 0xFF4D5055 : 0xFF43464B;
		int overlayColor = hovered ? 0x14FFFFFF : 0x08000000;

		this.fill(x, y, x + width, y + height, fillColor);
		this.fill(x, y, x + width, y + 1, topBorderColor);
		this.fill(x, y + height - 1, x + width, y + height, bottomBorderColor);
		this.fill(x, y, x + 1, y + height, topBorderColor);
		this.fill(x + width - 1, y, x + width, y + height, bottomBorderColor);

		if (width > 2 && height > 2) {
			this.fill(x + 1, y + 1, x + width - 1, y + height - 1, overlayColor);
		}
	}
}



