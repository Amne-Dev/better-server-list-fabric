package amdev.bsl.mixin.client;

import amdev.bsl.client.ServerMetadataStore;
import amdev.bsl.client.ServerOrdering;
import amdev.bsl.client.gui.CategoryFilterSidebarScreen;
import amdev.bsl.client.gui.CategoryEditScreen;
import amdev.bsl.client.gui.ServerBrowserScreen;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_500.class)
public abstract class JoinMultiplayerScreenMixin extends class_437 {
	protected JoinMultiplayerScreenMixin(class_2561 title) {
		super(title);
	}

	@Shadow
	protected class_4267 serverSelectionList;

	@Shadow
	private class_641 servers;

	@Shadow
	protected abstract void onSelectedChange();

	@Unique
	private class_4185 bslFavoriteButton;

	@Unique
	private class_4185 bslCategoryButton;

	@Unique
	private class_4185 bslFindServersButton;

	@Unique
	private class_342 bslSearchBox;

	@Unique
	private class_4185 bslCategoryFilterButton;

	@Unique
	private final List<class_4185> bslCategoryDropdownButtons = new ArrayList<>();

	@Unique
	private String bslActiveCategoryFilter = "";

	@Unique
	private boolean bslCategoryDropdownOpen;

	@Unique
	private int bslCategoryFilterX;

	@Unique
	private int bslCategoryFilterY;

	@Unique
	private int bslCategoryFilterWidth = 120;

	@Unique
	private static final int BSL_CONTROL_HEIGHT = 20;

	@Unique
	private static final int BSL_CONTROL_GAP = 4;

	@Unique
	private static final int BSL_TOP_Y = 36;

	@Unique
	private static final int BSL_MARGIN = 8;

	@Unique
	private static final int BSL_LIST_TOP_GAP = 8;

	@Unique
	private static final int BSL_LIST_BOTTOM_PADDING = 64;

	@Inject(method = "init", at = @At("TAIL"))
	private void bsl$addCategoryButtons(CallbackInfo ci) {
		int favoriteWidth = 84;
		int categoryWidth = 104;
		int findWidth = 84;
		int filterWidth = 104;
		int buttonsTotalWidth = favoriteWidth + categoryWidth + findWidth + filterWidth + BSL_CONTROL_GAP * 3;
		int availableWidth = Math.max(240, this.width - BSL_MARGIN * 2);
		int searchWidth = Math.max(140, availableWidth - buttonsTotalWidth - BSL_CONTROL_GAP);
		int buttonX = BSL_MARGIN + searchWidth + BSL_CONTROL_GAP;

		this.bslSearchBox = this.addButton(new class_342(this.minecraft.field_1772, BSL_MARGIN, BSL_TOP_Y, searchWidth, BSL_CONTROL_HEIGHT, "Search"));
		this.bslSearchBox.method_1887("Search servers");
		this.bslSearchBox.method_1863(value -> this.bsl$applyServerView(null));

		this.bslFavoriteButton = this.addButton(new class_4185(buttonX, BSL_TOP_Y, favoriteWidth, BSL_CONTROL_HEIGHT, "Fav", button -> this.bsl$toggleFavorite()));
		this.bslCategoryButton = this.addButton(new class_4185(buttonX + favoriteWidth + BSL_CONTROL_GAP, BSL_TOP_Y, categoryWidth, BSL_CONTROL_HEIGHT, "Category", button -> this.bsl$openCategoryEditor()));
		this.bslFindServersButton = this.addButton(new class_4185(buttonX + favoriteWidth + categoryWidth + BSL_CONTROL_GAP * 2, BSL_TOP_Y, findWidth, BSL_CONTROL_HEIGHT, "Find", button -> this.bsl$openServerBrowser()));
		this.bslCategoryFilterButton = this.addButton(new class_4185(buttonX + favoriteWidth + categoryWidth + findWidth + BSL_CONTROL_GAP * 3, BSL_TOP_Y, filterWidth, BSL_CONTROL_HEIGHT, "Show: All v", button -> this.bsl$toggleCategoryDropdown()));

		this.bslCategoryFilterX = this.bslCategoryFilterButton.x;
		this.bslCategoryFilterY = this.bslCategoryFilterButton.y + BSL_CONTROL_HEIGHT;
		this.bslCategoryFilterWidth = this.bslCategoryFilterButton.getWidth();

		this.bsl$layoutServerListArea();
		this.bsl$applyServerView(null);
	}

	@Inject(method = "refreshServerList", at = @At("TAIL"))
	private void bsl$sortOnRefresh(CallbackInfo ci) {
		this.bsl$applyServerView(null);
	}

	@Inject(method = "onSelectedChange", at = @At("TAIL"))
	private void bsl$updateButtonsOnSelection(CallbackInfo ci) {
		this.bsl$updateButtons();
	}

	@Inject(method = "removed", at = @At("TAIL"))
	private void bsl$saveStore(CallbackInfo ci) {
		this.bsl$closeCategoryDropdown();
		ServerMetadataStore.save();
	}
	@Unique
	private void bsl$toggleFavorite() {
		class_642 selected = this.bsl$getSelectedServerData();
		if (selected == null) {
			return;
		}

		String key = selected.field_3761;
		boolean nextValue = !ServerMetadataStore.isFavorite(key);
		ServerMetadataStore.setFavorite(key, nextValue);
		this.bsl$applyServerView(key);
	}

	@Unique
	private void bsl$openCategoryEditor() {
		class_642 selected = this.bsl$getSelectedServerData();
		if (selected == null) {
			return;
		}

		String key = selected.field_3761;
		String current = ServerMetadataStore.getCategory(key);
		this.minecraft.method_1507(new CategoryEditScreen((class_500) (Object) this, current, next -> {
			ServerMetadataStore.setCategory(key, next);
			if (!this.bslActiveCategoryFilter.isEmpty() && !ServerMetadataStore.getKnownCategories().contains(this.bslActiveCategoryFilter)) {
				this.bslActiveCategoryFilter = "";
			}
			this.bsl$applyServerView(key);
		}));
	}

	@Unique
	private void bsl$openServerBrowser() {
		this.bsl$closeCategoryDropdown();
		this.minecraft.method_1507(new ServerBrowserScreen((class_500) (Object) this));
	}

	@Unique
	public void bsl$applyServerView(String preferredAddress) {
		if (this.serverSelectionList == null || this.servers == null) {
			return;
		}

		String selectedAddress = preferredAddress;
		if (selectedAddress == null) {
			class_642 selected = this.bsl$getSelectedServerData();
			if (selected != null) {
				selectedAddress = selected.field_3761;
			}
		}

		ServerOrdering.reorder(this.servers);
		this.serverSelectionList.method_20125(this.servers);
		this.bsl$filterEntries();

		this.bsl$restoreSelection(selectedAddress);
		this.onSelectedChange();
		this.bsl$updateButtons();
	}

	@Unique
	private void bsl$filterEntries() {
		String query = this.bsl$getSearchQuery();
		String categoryFilter = this.bslActiveCategoryFilter;

		ServerSelectionListAccessor accessor = (ServerSelectionListAccessor) this.serverSelectionList;
		List<class_4267.class_4270> onlineServers = accessor.bsl$getOnlineServers();
		onlineServers.removeIf(entry -> {
			class_642 data = entry.method_20133();
			return !this.bsl$matchesSearch(data, query) || !this.bsl$matchesCategory(data, categoryFilter);
		});
		accessor.bsl$refreshEntries();
	}

	@Unique
	private void bsl$restoreSelection(String serverAddress) {
		if (serverAddress == null) {
			return;
		}

		for (class_4267.class_504 entry : this.serverSelectionList.children()) {
			if (!(entry instanceof class_4267.class_4270)) {
				continue;
			}
			class_642 data = ((class_4267.class_4270) entry).method_20133();
			if (data != null && serverAddress.equalsIgnoreCase(data.field_3761)) {
				this.serverSelectionList.method_20122(entry);
				break;
			}
		}
	}

	@Unique
	private void bsl$updateButtons() {
		if (this.bslFavoriteButton == null || this.bslCategoryButton == null || this.bslFindServersButton == null || this.bslCategoryFilterButton == null) {
			return;
		}

		class_642 selected = this.bsl$getSelectedServerData();
		boolean hasSelection = selected != null;
		this.bslFavoriteButton.active = hasSelection;
		this.bslCategoryButton.active = hasSelection;
		this.bslFindServersButton.active = true;

		if (!hasSelection) {
			this.bslFavoriteButton.setMessage("Fav");
			this.bslCategoryButton.setMessage("Category");
			this.bsl$updateCategoryFilterButton();
			return;
		}

		boolean favorite = ServerMetadataStore.isFavorite(selected.field_3761);
		this.bslFavoriteButton.setMessage((favorite ? "Unfav" : "Fav"));
		this.bslCategoryButton.setMessage("Category");
		this.bsl$updateCategoryFilterButton();
	}

	@Unique
	private String bsl$getSearchQuery() {
		if (this.bslSearchBox == null) {
			return "";
		}
		return this.bslSearchBox.method_1882().trim().toLowerCase(Locale.ROOT);
	}

	@Unique
	private boolean bsl$matchesSearch(class_642 serverData, String query) {
		if (serverData == null) {
			return false;
		}
		if (query.isEmpty()) {
			return true;
		}

		String category = ServerMetadataStore.getCategory(serverData.field_3761);
		boolean favorite = ServerMetadataStore.isFavorite(serverData.field_3761);
		String haystack = (
			(serverData.field_3752 == null ? "" : serverData.field_3752) + " " +
			(serverData.field_3761 == null ? "" : serverData.field_3761) + " " +
			category + " " +
			(favorite ? "favorite fav starred" : "")
		).toLowerCase(Locale.ROOT);

		String[] terms = query.split("\\s+");
		for (String term : terms) {
			if (!term.isEmpty() && !haystack.contains(term)) {
				return false;
			}
		}
		return true;
	}

	@Unique
	private boolean bsl$matchesCategory(class_642 serverData, String categoryFilter) {
		if (serverData == null) {
			return false;
		}
		if (categoryFilter == null || categoryFilter.isEmpty()) {
			return true;
		}
		return categoryFilter.equalsIgnoreCase(ServerMetadataStore.getCategory(serverData.field_3761));
	}

	@Unique
	private void bsl$toggleCategoryDropdown() {
		this.bsl$closeCategoryDropdown();
		this.minecraft.method_1507(new CategoryFilterSidebarScreen((class_500) (Object) this, this.bslActiveCategoryFilter, category -> {
			this.bslActiveCategoryFilter = category == null ? "" : category;
			
		}));
	}

	@Unique
	private void bsl$updateCategoryFilterButton() {
		if (this.bslCategoryFilterButton == null) {
			return;
		}
		String label = this.bslActiveCategoryFilter.isEmpty() ? "All" : this.bsl$abbreviate(this.bslActiveCategoryFilter, 8);
		this.bslCategoryFilterButton.setMessage(("Show: " + label + " v"));
	}

	@Unique
	private void bsl$cycleCategoryFilter() {
		List<String> options = new ArrayList<>();
		options.add("");
		options.addAll(ServerMetadataStore.getKnownCategories());

		if (options.isEmpty()) {
			return;
		}

		int currentIndex = 0;
		for (int i = 0; i < options.size(); i++) {
			if (options.get(i).equalsIgnoreCase(this.bslActiveCategoryFilter)) {
				currentIndex = i;
				break;
			}
		}

		int nextIndex = (currentIndex + 1) % options.size();
		this.bslActiveCategoryFilter = options.get(nextIndex);
		
	}

	@Unique
	private void bsl$openCategoryDropdown() {
		this.bsl$closeCategoryDropdown();

		List<String> options = new ArrayList<>();
		options.add("");
		options.addAll(ServerMetadataStore.getKnownCategories());

		int y = Math.max(8, this.bslCategoryFilterY - options.size() * 20);
		for (String option : options) {
			String label = option.isEmpty() ? "All" : this.bsl$abbreviate(option, 16);
			class_4185 optionButton = this.addButton(new class_4185(this.bslCategoryFilterX, y, this.bslCategoryFilterWidth, 20, label, button -> this.bsl$setCategoryFilter(option)));
			this.bslCategoryDropdownButtons.add(optionButton);
			y += 20;
		}

		this.bslCategoryDropdownOpen = true;
	}

	@Unique
	private void bsl$closeCategoryDropdown() {
		if (this.bslCategoryDropdownButtons.isEmpty()) {
			this.bslCategoryDropdownOpen = false;
			return;
		}

		for (class_4185 button : this.bslCategoryDropdownButtons) {
			this.buttons.remove(button);
			this.children.remove(button);
		}
		this.bslCategoryDropdownButtons.clear();
		this.bslCategoryDropdownOpen = false;
	}

	@Unique
	private void bsl$setCategoryFilter(String category) {
		this.bslActiveCategoryFilter = category == null ? "" : category;
		this.bsl$closeCategoryDropdown();
		this.bsl$applyServerView(null);
	}

	@Unique
	private void bsl$layoutServerListArea() {
		if (this.serverSelectionList == null) {
			return;
		}

		int controlsBottom = this.bslCategoryFilterButton == null
			? BSL_TOP_Y + BSL_CONTROL_HEIGHT
			: this.bslCategoryFilterButton.y + BSL_CONTROL_HEIGHT;
		int top = Math.max(48, controlsBottom + BSL_LIST_TOP_GAP);
		this.serverSelectionList.updateSize(this.width, this.height, top, this.height - BSL_LIST_BOTTOM_PADDING);
	}

	@Unique
	private String bsl$abbreviate(String value, int maxLength) {
		if (value.length() <= maxLength) {
			return value;
		}
		return value.substring(0, maxLength - 3) + "...";
	}

	@Unique
	private class_642 bsl$getSelectedServerData() {
		class_4267.class_504 selectedEntry = this.serverSelectionList.getSelected();
		if (selectedEntry instanceof class_4267.class_4270) {
			return ((class_4267.class_4270) selectedEntry).method_20133();
		}
		return null;
	}
}


