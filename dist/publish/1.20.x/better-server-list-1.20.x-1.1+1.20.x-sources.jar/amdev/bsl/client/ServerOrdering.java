package amdev.bsl.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_641;
import net.minecraft.class_642;

public final class ServerOrdering {
	private static final Comparator<class_642> ORDER = Comparator
		.comparing((class_642 serverData) -> !ServerMetadataStore.isFavorite(serverData.field_3761))
		.thenComparing((class_642 serverData) -> ServerMetadataStore.getCategory(serverData.field_3761).isBlank())
		.thenComparing(
			(class_642 serverData) -> normalize(ServerMetadataStore.getCategory(serverData.field_3761)),
			String::compareTo
		)
		.thenComparing(ServerOrdering::name, String.CASE_INSENSITIVE_ORDER)
		.thenComparing(ServerOrdering::address, String.CASE_INSENSITIVE_ORDER);

	private ServerOrdering() {
	}

	public static void reorder(class_641 serverList) {
		if (serverList == null || serverList.method_2984() < 2) {
			return;
		}

		List<class_642> original = new ArrayList<>(serverList.method_2984());
		for (int i = 0; i < serverList.method_2984(); i++) {
			original.add(serverList.method_2982(i));
		}

		List<class_642> ordered = new ArrayList<>(original);
		ordered.sort(ORDER);

		boolean changed = false;
		for (int i = 0; i < ordered.size(); i++) {
			if (ordered.get(i) != original.get(i)) {
				changed = true;
				serverList.method_2980(i, ordered.get(i));
			}
		}

		if (changed) {
			serverList.method_2987();
		}
	}

	private static String name(class_642 serverData) {
		return serverData.field_3752 == null ? "" : serverData.field_3752;
	}

	private static String address(class_642 serverData) {
		return serverData.field_3761 == null ? "" : serverData.field_3761;
	}

	private static String normalize(String value) {
		if (value == null || value.isBlank()) {
			return "~";
		}
		return value.toLowerCase(Locale.ROOT);
	}
}
