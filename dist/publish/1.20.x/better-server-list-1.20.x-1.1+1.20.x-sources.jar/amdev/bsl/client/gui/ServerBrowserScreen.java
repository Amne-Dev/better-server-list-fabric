package amdev.bsl.client.gui;

import amdev.bsl.client.PublicServerCatalog;
import amdev.bsl.client.ServerMetadataStore;
import amdev.bsl.client.ServerOrdering;
import amdev.bsl.mixin.client.JoinMultiplayerScreenInvoker;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;

public final class ServerBrowserScreen extends class_437 {
	private static final int PAGE_SIZE = 8;
	private static final int ROW_HEIGHT = 36;
	private static final String MCSRSTAT_ICON_PREFIX = "https://api.mcsrvstat.us/icon/";
	private static final String MCSRSTAT_ICON_PREFIX_HTTP = "http://api.mcsrvstat.us/icon/";
	private static final String MINE_SPARK_STATUS_TEMPLATE = "https://srvstat.minespark.org/general/%s";
	private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
		.followRedirects(HttpClient.Redirect.NORMAL)
		.connectTimeout(Duration.ofSeconds(8))
		.build();

	private final class_500 parent;
	private final List<PublicServerCatalog.Entry> allEntries = new ArrayList<>();
	private final List<PublicServerCatalog.Entry> filteredEntries = new ArrayList<>();
	private final List<class_4185> resultButtons = new ArrayList<>();
	private final Map<String, class_2960> logoTextures = new HashMap<>();
	private final Set<String> logoLoading = new HashSet<>();
	private final List<class_2960> registeredTextures = new ArrayList<>();
	private class_342 searchField;
	private class_4185 previousPageButton;
	private class_4185 nextPageButton;
	private class_4185 addButton;
	private class_4185 openWebsiteButton;
	private class_4185 refreshApiButton;
	private PublicServerCatalog.Entry selected;
	private int currentPage;
	private String statusMessage = "";
	private int buttonX;
	private int buttonWidth;
	private int listTop;
	private class_1799 loadingIcon;
	private long nextLoadingIconRetryAt;
	private boolean loadingLive;
	private CompletableFuture<PublicServerCatalog.LoadResult> liveLoadFuture;

	public ServerBrowserScreen(class_500 parent) {
		super(class_2561.method_43470("Find Servers"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		this.bsl$cancelLiveLoad();
		this.allEntries.clear();
		this.filteredEntries.clear();
		this.selected = null;
		this.currentPage = 0;
		this.loadingIcon = class_1799.field_8037;
		this.nextLoadingIconRetryAt = 0L;

		this.listTop = 46;
		this.buttonWidth = Math.min(this.field_22789 - 20, Math.max(575, this.field_22789 - 40));
		this.buttonX = (this.field_22789 - this.buttonWidth) / 2;

		this.searchField = this.method_37063(
			new class_342(this.field_22793, this.buttonX, 18, this.buttonWidth, 20, class_2561.method_43470("Search public servers"))
		);
		this.searchField.method_47404(class_2561.method_43470("Search name, address, category, tags"));
		this.searchField.method_1863(value -> {
			this.currentPage = 0;
			this.bsl$refreshFilteredEntries();
		});
		this.method_48265(this.searchField);

		this.resultButtons.clear();
		for (int i = 0; i < PAGE_SIZE; i++) {
			final int slot = i;
			class_4185 button = this.method_37063(
				class_4185.method_46430(class_2561.method_43473(), b -> this.bsl$selectFromSlot(slot)).method_46434(
					this.buttonX,
					this.listTop + i * ROW_HEIGHT,
					this.buttonWidth,
					ROW_HEIGHT - 2
				).method_46431()
			);
			this.resultButtons.add(button);
		}

		int controlsY = this.field_22790 - 54;
		int prevX = this.buttonX;
		int nextX = prevX + 80;
		int addX = nextX + 80;
		int websiteX = addX + 115;
		int reloadX = websiteX + 115;
		int doneX = this.buttonX + this.buttonWidth - 75;

		this.previousPageButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("< Prev"), b -> this.bsl$changePage(-1)).method_46434(prevX, controlsY, 75, 20).method_46431()
		);
		this.nextPageButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Next >"), b -> this.bsl$changePage(1)).method_46434(nextX, controlsY, 75, 20).method_46431()
		);
		this.addButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Add Selected"), b -> this.bsl$addSelectedServer()).method_46434(addX, controlsY, 110, 20).method_46431()
		);
		this.openWebsiteButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Open Website"), b -> this.bsl$openSelectedWebsite()).method_46434(websiteX, controlsY, 110, 20).method_46431()
		);
		this.refreshApiButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Reload API"), b -> this.bsl$loadLiveCatalog(true)).method_46434(reloadX, controlsY, 100, 20).method_46431()
		);
		this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Done"), b -> this.field_22787.method_1507(this.parent)).method_46434(doneX, controlsY, 75, 20).method_46431()
		);

		this.loadingLive = true;
		this.statusMessage = "Loading live server catalog...";
		this.bsl$refreshFilteredEntries();
		this.bsl$loadLiveCatalog(false);
	}

	@Override
	public void method_25419() {
		this.bsl$cancelLiveLoad();
		this.bsl$releaseLogoTextures();
		this.field_22787.method_1507(this.parent);
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		guiGraphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xB0101010);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 6, 0xFFFFFFFF);
		guiGraphics.method_25303(this.field_22793, "Results: " + this.filteredEntries.size(), 10, this.field_22790 - 76, 0xFFA0A0A0);
		if (!this.statusMessage.isBlank()) {
			guiGraphics.method_25303(this.field_22793, this.statusMessage, 10, this.field_22790 - 66, 0xFF80FF80);
		}

		if (this.loadingLive) {
			this.bsl$renderLoadingIndicator(guiGraphics);
		} else {
			this.bsl$renderRows(guiGraphics);
		}
	}

	private void bsl$renderRows(class_332 guiGraphics) {
		int pageStart = this.currentPage * PAGE_SIZE;
		for (int i = 0; i < PAGE_SIZE; i++) {
			int index = pageStart + i;
			if (index < 0 || index >= this.filteredEntries.size()) {
				continue;
			}

			PublicServerCatalog.Entry entry = this.filteredEntries.get(index);
			int rowX = this.buttonX;
			int rowY = this.listTop + i * ROW_HEIGHT;

			if (entry.equals(this.selected)) {
				guiGraphics.method_49601(rowX - 1, rowY - 1, this.buttonWidth + 2, ROW_HEIGHT, 0xFFFFD67A);
			}

			this.bsl$ensureLogoTexture(entry);
			this.bsl$drawLogo(guiGraphics, entry, rowX + 6, rowY + 8);

			guiGraphics.method_51433(this.field_22793, this.bsl$abbreviate(entry.name(), 38), rowX + 28, rowY + 6, 0xFFFFFFFF, false);
			guiGraphics.method_51433(this.field_22793, this.bsl$abbreviate(entry.address(), 45), rowX + 28, rowY + 18, 0xFF9FA7B0, false);

			String playersText = this.bsl$playersText(entry);
			int playersColor = entry.players() > 0 ? 0xFF9DE27A : 0xFFA0A0A0;
			guiGraphics.method_51433(this.field_22793, playersText, rowX + this.buttonWidth - 120, rowY + 12, playersColor, false);
		}
	}

	private void bsl$renderLoadingIndicator(class_332 guiGraphics) {
		float wave = (float) Math.sin((class_156.method_658() % 1600L) / 1600.0 * Math.PI * 2.0);
		float pulse = (wave + 1.0f) * 0.5f;
		int iconX = this.field_22789 / 2 - 8;
		int iconY = this.listTop + PAGE_SIZE * ROW_HEIGHT / 2 - 8;

		class_1799 icon = this.bsl$getLoadingIcon();
		if (!icon.method_7960()) {
			guiGraphics.method_51427(icon, iconX, iconY);
		} else {
			this.bsl$renderFallbackIcon(guiGraphics, iconX, iconY, true);
		}
		int darkAlpha = ((int) ((1.0f - pulse) * 120.0f)) << 24;
		int lightAlpha = ((int) (pulse * 70.0f)) << 24;
		guiGraphics.method_25294(iconX, iconY, iconX + 16, iconY + 16, darkAlpha);
		guiGraphics.method_25294(iconX, iconY, iconX + 16, iconY + 16, lightAlpha | 0x00FFFFFF);

		int textAlpha = ((int) (140 + pulse * 115.0f)) << 24;
		guiGraphics.method_25300(this.field_22793, "Loading...", this.field_22789 / 2, iconY + 24, textAlpha | 0xD8C8FF);
	}

	private void bsl$drawLogo(class_332 guiGraphics, PublicServerCatalog.Entry entry, int x, int y) {
		String key = this.bsl$logoKey(entry.address());
		class_2960 identifier = this.logoTextures.get(key);
		if (identifier != null) {
			guiGraphics.method_25291(identifier, x, y, 0, 0.0f, 0.0f, 16, 16, 16, 16);
			return;
		}

		class_1799 icon = this.bsl$getLoadingIcon();
		if (!icon.method_7960()) {
			guiGraphics.method_51427(icon, x, y);
		} else {
			this.bsl$renderFallbackIcon(guiGraphics, x, y, false);
		}
	}

	private class_1799 bsl$getLoadingIcon() {
		if (this.loadingIcon != null && !this.loadingIcon.method_7960()) {
			return this.loadingIcon;
		}

		long now = class_156.method_658();
		if (now < this.nextLoadingIconRetryAt) {
			return class_1799.field_8037;
		}

		try {
			this.loadingIcon = new class_1799(class_1802.field_27063);
			return this.loadingIcon;
		} catch (Exception ignored) {
			this.nextLoadingIconRetryAt = now + 1000L;
			return class_1799.field_8037;
		}
	}

	private void bsl$renderFallbackIcon(class_332 guiGraphics, int x, int y, boolean loading) {
		int fillColor = loading ? 0xFF6C5D92 : 0xFF4B4F57;
		int borderColor = loading ? 0xFFD8C8FF : 0xFF9AA0AA;
		guiGraphics.method_25294(x, y, x + 16, y + 16, fillColor);
		guiGraphics.method_49601(x, y, 16, 16, borderColor);
	}

	private void bsl$refreshFilteredEntries() {
		String query = this.searchField == null ? "" : this.searchField.method_1882().trim().toLowerCase(Locale.ROOT);

		this.filteredEntries.clear();
		for (PublicServerCatalog.Entry entry : this.allEntries) {
			if (this.bsl$matchesQuery(entry, query)) {
				this.filteredEntries.add(entry);
			}
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		if (this.currentPage > maxPage) {
			this.currentPage = maxPage;
		}
		if (this.selected != null && !this.filteredEntries.contains(this.selected)) {
			this.selected = null;
		}

		this.bsl$refreshResultButtons();
		this.bsl$refreshActionButtons();
	}

	private void bsl$loadLiveCatalog(boolean forceRefresh) {
		this.bsl$cancelLiveLoad();

		if (!forceRefresh) {
			PublicServerCatalog.LoadResult cached = PublicServerCatalog.getSessionCachedResult();
			if (cached != null) {
				this.loadingLive = false;
				this.statusMessage = cached.fromLiveApi()
					? "Loaded " + cached.entries().size() + " servers from session cache."
					: "Using cached bundled catalog from this session.";
				this.allEntries.clear();
				this.allEntries.addAll(cached.entries());
				this.filteredEntries.clear();
				this.selected = null;
				this.currentPage = 0;
				this.bsl$refreshFilteredEntries();
				return;
			}
		}

		if (this.refreshApiButton != null) {
			this.refreshApiButton.field_22763 = false;
		}
		this.loadingLive = true;
		this.statusMessage = forceRefresh ? "Reloading live server catalog..." : "Loading live server catalog...";
		this.allEntries.clear();
		this.filteredEntries.clear();
		this.selected = null;
		this.currentPage = 0;
		this.bsl$refreshFilteredEntries();

		this.liveLoadFuture = forceRefresh
			? PublicServerCatalog.reloadPreferredAsync(this.field_22787.method_1478())
			: PublicServerCatalog.loadPreferredAsync(this.field_22787.method_1478());
		this.liveLoadFuture.whenComplete((result, throwable) -> this.field_22787.execute(() -> {
			if (this.field_22787 == null || this.field_22787.field_1755 != this) {
				return;
			}

			this.loadingLive = false;
			if (this.refreshApiButton != null) {
				this.refreshApiButton.field_22763 = true;
			}

			PublicServerCatalog.LoadResult safeResult;
			if (throwable != null || result == null || result.entries() == null) {
				safeResult = new PublicServerCatalog.LoadResult(PublicServerCatalog.loadBundled(this.field_22787.method_1478()), false);
				this.statusMessage = "Live API unavailable. Showing bundled catalog.";
			} else {
				safeResult = result;
				if (safeResult.fromLiveApi()) {
					this.statusMessage = "Loaded " + safeResult.entries().size() + " servers from live API.";
				} else {
					this.statusMessage = "Live API unavailable. Showing bundled catalog.";
				}
			}

			this.allEntries.clear();
			this.allEntries.addAll(safeResult.entries());
			this.currentPage = 0;
			this.selected = null;
			this.bsl$refreshFilteredEntries();
		}));
	}

	private void bsl$cancelLiveLoad() {
		if (this.liveLoadFuture != null) {
			this.liveLoadFuture.cancel(true);
			this.liveLoadFuture = null;
		}
	}

	private void bsl$refreshResultButtons() {
		if (this.loadingLive) {
			for (class_4185 button : this.resultButtons) {
				button.field_22764 = false;
				button.field_22763 = false;
			}
			return;
		}

		int pageStart = this.currentPage * PAGE_SIZE;
		for (int i = 0; i < this.resultButtons.size(); i++) {
			class_4185 button = this.resultButtons.get(i);
			int index = pageStart + i;
			if (index < this.filteredEntries.size()) {
				button.field_22764 = true;
				button.field_22763 = true;
				button.method_25355(class_2561.method_43473());
			} else {
				button.field_22764 = false;
				button.field_22763 = false;
			}
		}
	}

	private void bsl$refreshActionButtons() {
		if (this.loadingLive) {
			this.previousPageButton.field_22763 = false;
			this.nextPageButton.field_22763 = false;
			this.addButton.field_22763 = false;
			this.openWebsiteButton.field_22763 = false;
			return;
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		this.previousPageButton.field_22763 = this.currentPage > 0;
		this.nextPageButton.field_22763 = this.currentPage < maxPage;

		if (this.selected == null) {
			this.addButton.field_22763 = false;
			this.openWebsiteButton.field_22763 = false;
			return;
		}

		this.addButton.field_22763 = true;
		this.openWebsiteButton.field_22763 = !this.selected.website().isBlank();
	}

	private void bsl$selectFromSlot(int slot) {
		if (this.loadingLive) {
			return;
		}

		int index = this.currentPage * PAGE_SIZE + slot;
		if (index < 0 || index >= this.filteredEntries.size()) {
			return;
		}
		this.selected = this.filteredEntries.get(index);
		this.statusMessage = "";
		this.bsl$refreshActionButtons();
	}

	private void bsl$changePage(int delta) {
		if (this.loadingLive) {
			return;
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		this.currentPage = Math.max(0, Math.min(maxPage, this.currentPage + delta));
		this.bsl$refreshResultButtons();
		this.bsl$refreshActionButtons();
	}

	private void bsl$addSelectedServer() {
		if (this.selected == null) {
			return;
		}

		class_641 serverList = this.parent.method_2529();
		if (serverList.method_44295(this.selected.address()) != null) {
			this.statusMessage = "Server already exists in your list.";
			return;
		}

		class_642 serverData = new class_642(this.selected.name(), this.selected.address(), class_642.class_8678.field_45611);
		serverList.method_2988(serverData, false);
		if (ServerMetadataStore.getCategory(serverData.field_3761).isBlank() && !this.selected.category().isBlank()) {
			ServerMetadataStore.setCategory(serverData.field_3761, this.selected.category());
		}
		ServerOrdering.reorder(serverList);
		serverList.method_2987();
		((JoinMultiplayerScreenInvoker) this.parent).bsl$refreshServerList();

		this.statusMessage = "Added " + this.selected.name() + ".";
	}

	private void bsl$openSelectedWebsite() {
		if (this.selected == null || this.selected.website().isBlank()) {
			return;
		}
		class_407.method_49623(this, this.selected.website());
	}

	private void bsl$ensureLogoTexture(PublicServerCatalog.Entry entry) {
		if (entry.logoUrl().isBlank()) {
			return;
		}

		String key = this.bsl$logoKey(entry.address());
		if (this.logoTextures.containsKey(key) || this.logoLoading.contains(key)) {
			return;
		}

		this.logoLoading.add(key);
		CompletableFuture
			.supplyAsync(() -> this.bsl$downloadLogo(entry.logoUrl()))
			.whenComplete((image, throwable) -> this.field_22787.execute(() -> {
				this.logoLoading.remove(key);
				if (throwable != null || image == null) {
					return;
				}

				try {
					class_2960 textureId = new class_2960("better-server-list", "server_logo/" + Integer.toUnsignedString(key.hashCode()));
					class_1043 texture = new class_1043(image);
					texture.method_4524();
					this.field_22787.method_1531().method_4616(textureId, texture);
					this.logoTextures.put(key, textureId);
					this.registeredTextures.add(textureId);
				} catch (Exception exception) {
					image.close();
				}
			}));
	}

	private class_1011 bsl$downloadLogo(String logoUrl) {
		try {
			class_1011 directDataImage = this.bsl$decodeDataImage(logoUrl);
			if (directDataImage != null) {
				return directDataImage;
			}

			String mcsAddress = this.bsl$extractMcsrvstatAddress(logoUrl);
			if (!mcsAddress.isEmpty()) {
				class_1011 fallbackStatusIcon = this.bsl$downloadMinesparkStatusIcon(mcsAddress);
				if (fallbackStatusIcon != null) {
					return fallbackStatusIcon;
				}
			}

			HttpRequest request = HttpRequest.newBuilder()
				.GET()
				.uri(URI.create(logoUrl))
				.timeout(Duration.ofSeconds(8))
				.header("Accept", "image/png,image/*")
				.header("User-Agent", "better-server-list-fabric/1.1")
				.build();
			HttpResponse<byte[]> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofByteArray());
			if (response.statusCode() < 200 || response.statusCode() >= 300) {
				return null;
			}
			return class_1011.method_4309(new ByteArrayInputStream(response.body()));
		} catch (Exception exception) {
			return null;
		}
	}

	private class_1011 bsl$downloadMinesparkStatusIcon(String address) {
		try {
			String encodedAddress = URLEncoder.encode(address, StandardCharsets.UTF_8);
			String endpoint = String.format(MINE_SPARK_STATUS_TEMPLATE, encodedAddress);
			HttpRequest request = HttpRequest.newBuilder()
				.GET()
				.uri(URI.create(endpoint))
				.timeout(Duration.ofSeconds(8))
				.header("Accept", "application/json")
				.header("User-Agent", "better-server-list-fabric/1.1")
				.build();
			HttpResponse<String> response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
			if (response.statusCode() < 200 || response.statusCode() >= 300) {
				return null;
			}

			JsonElement parsed = new JsonParser().parse(response.body());
			if (!parsed.isJsonObject()) {
				return null;
			}

			JsonObject object = parsed.getAsJsonObject();
			JsonElement iconElement = object.get("icon");
			if (iconElement == null || !iconElement.isJsonPrimitive()) {
				return null;
			}

			return this.bsl$decodeDataImage(iconElement.getAsString());
		} catch (Exception ignored) {
			return null;
		}
	}

	private class_1011 bsl$decodeDataImage(String dataUrl) {
		if (dataUrl == null || !dataUrl.startsWith("data:image/")) {
			return null;
		}

		int commaIndex = dataUrl.indexOf(',');
		if (commaIndex <= 0 || commaIndex >= dataUrl.length() - 1) {
			return null;
		}

		String payload = dataUrl.substring(commaIndex + 1).trim();
		if (payload.contains("%")) {
			try {
				payload = java.net.URLDecoder.decode(payload, StandardCharsets.UTF_8);
			} catch (Exception ignored) {
				// Keep original payload and try decode paths below.
			}
		}

		byte[] decoded = this.bsl$tryBase64Decode(payload);
		if (decoded == null || decoded.length == 0) {
			return null;
		}

		try {
			return class_1011.method_4309(new ByteArrayInputStream(decoded));
		} catch (Exception ignored) {
			return null;
		}
	}

	private byte[] bsl$tryBase64Decode(String payload) {
		try {
			return Base64.getDecoder().decode(payload);
		} catch (Exception ignored) {
		}
		try {
			return Base64.getMimeDecoder().decode(payload);
		} catch (Exception ignored) {
		}
		try {
			return Base64.getUrlDecoder().decode(payload);
		} catch (Exception ignored) {
		}
		return null;
	}

	private String bsl$extractMcsrvstatAddress(String logoUrl) {
		if (logoUrl == null || logoUrl.isEmpty()) {
			return "";
		}
		String normalized = logoUrl;
		if (normalized.startsWith(MCSRSTAT_ICON_PREFIX)) {
			normalized = normalized.substring(MCSRSTAT_ICON_PREFIX.length());
		} else if (normalized.startsWith(MCSRSTAT_ICON_PREFIX_HTTP)) {
			normalized = normalized.substring(MCSRSTAT_ICON_PREFIX_HTTP.length());
		} else {
			return "";
		}

		int queryIndex = normalized.indexOf('?');
		if (queryIndex >= 0) {
			normalized = normalized.substring(0, queryIndex);
		}
		return normalized.trim();
	}

	private void bsl$releaseLogoTextures() {
		if (this.field_22787 == null) {
			return;
		}
		for (class_2960 identifier : this.registeredTextures) {
			this.field_22787.method_1531().method_4615(identifier);
		}
		this.registeredTextures.clear();
		this.logoTextures.clear();
		this.logoLoading.clear();
	}

	private boolean bsl$matchesQuery(PublicServerCatalog.Entry entry, String query) {
		if (query.isBlank()) {
			return true;
		}

		String searchable = entry.searchableText().toLowerCase(Locale.ROOT);
		String[] terms = query.split("\\s+");
		for (String term : terms) {
			if (!term.isEmpty() && !searchable.contains(term)) {
				return false;
			}
		}
		return true;
	}

	private String bsl$playersText(PublicServerCatalog.Entry entry) {
		if (entry.players() >= 0 && entry.maxPlayers() > 0) {
			return "Players: " + entry.players() + "/" + entry.maxPlayers();
		}
		if (entry.players() >= 0) {
			return "Players: " + entry.players();
		}
		return "Players: --";
	}

	private String bsl$logoKey(String address) {
		return address == null ? "" : address.trim().toLowerCase(Locale.ROOT);
	}

	private String bsl$abbreviate(String value, int maxLength) {
		if (value.length() <= maxLength) {
			return value;
		}
		return value.substring(0, maxLength - 3) + "...";
	}
}
