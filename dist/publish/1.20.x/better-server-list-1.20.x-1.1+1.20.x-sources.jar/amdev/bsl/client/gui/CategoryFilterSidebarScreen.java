package amdev.bsl.client.gui;

import amdev.bsl.client.ServerMetadataStore;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CategoryFilterSidebarScreen extends class_437 {
	private static final int PANEL_MARGIN = 8;
	private static final int PANEL_WIDTH = 220;
	private static final int PANEL_PADDING = 8;
	private static final int HEADER_HEIGHT = 30;
	private static final int FOOTER_HEIGHT = 56;
	private static final int ROW_HEIGHT = 20;
	private static final int ROW_GAP = 2;

	private final class_437 parent;
	private final Consumer<String> onSelect;
	private final String activeCategory;
	private final int page;

	public CategoryFilterSidebarScreen(class_437 parent, String activeCategory, Consumer<String> onSelect) {
		this(parent, activeCategory, onSelect, 0);
	}

	private CategoryFilterSidebarScreen(class_437 parent, String activeCategory, Consumer<String> onSelect, int page) {
		super(class_2561.method_43470("Category Filter"));
		this.parent = parent;
		this.onSelect = onSelect;
		this.activeCategory = activeCategory == null ? "" : activeCategory;
		this.page = Math.max(0, page);
	}

	@Override
	protected void method_25426() {
		List<String> options = this.bsl$buildOptions();
		int pageSize = this.bsl$getPageSize();
		int totalPages = Math.max(1, (options.size() + pageSize - 1) / pageSize);
		int currentPage = Math.max(0, Math.min(this.page, totalPages - 1));

		int panelLeft = this.field_22789 - PANEL_WIDTH - PANEL_MARGIN;
		int panelTop = PANEL_MARGIN;
		int panelHeight = this.field_22790 - PANEL_MARGIN * 2;
		int buttonX = panelLeft + PANEL_PADDING;
		int buttonWidth = PANEL_WIDTH - PANEL_PADDING * 2;
		int from = currentPage * pageSize;
		int to = Math.min(options.size(), from + pageSize);
		int y = panelTop + HEADER_HEIGHT;

		for (int i = from; i < to; i++) {
			String option = options.get(i);
			String label = this.bsl$formatOption(option);
			this.method_37063(
				class_4185.method_46430(class_2561.method_43470(label), button -> this.bsl$selectAndClose(option))
					.method_46434(buttonX, y, buttonWidth, ROW_HEIGHT)
					.method_46431()
			);
			y += ROW_HEIGHT + ROW_GAP;
		}

		int navY = panelTop + panelHeight - FOOTER_HEIGHT;
		int navWidth = (buttonWidth - PANEL_PADDING) / 2;
		class_4185 prevButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("< Prev"), button -> this.bsl$openPage(currentPage - 1))
				.method_46434(buttonX, navY, navWidth, ROW_HEIGHT)
				.method_46431()
		);
		prevButton.field_22763 = currentPage > 0;

		class_4185 nextButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Next >"), button -> this.bsl$openPage(currentPage + 1))
				.method_46434(buttonX + navWidth + PANEL_PADDING, navY, navWidth, ROW_HEIGHT)
				.method_46431()
		);
		nextButton.field_22763 = currentPage < totalPages - 1;

		this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Done"), button -> this.method_25419())
				.method_46434(buttonX, navY + ROW_HEIGHT + 4, buttonWidth, ROW_HEIGHT)
				.method_46431()
		);
	}

	@Override
	public boolean method_25422() {
		return true;
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(this.parent);
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		int panelLeft = this.field_22789 - PANEL_WIDTH - PANEL_MARGIN;
		int panelTop = PANEL_MARGIN;
		int panelHeight = this.field_22790 - PANEL_MARGIN * 2;

		this.parent.method_25394(guiGraphics, mouseX, mouseY, partialTick);
		guiGraphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x6A000000);
		guiGraphics.method_25294(panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + panelHeight, 0xD0101010);
		int listTop = panelTop + HEADER_HEIGHT - 2;
		int listBottom = panelTop + panelHeight - FOOTER_HEIGHT + 2;
		guiGraphics.method_25294(panelLeft + 2, listTop, panelLeft + PANEL_WIDTH - 2, listBottom, 0xFF101010);
		guiGraphics.method_27534(this.field_22793, this.field_22785, panelLeft + PANEL_WIDTH / 2, panelTop + 8, 0xFFFFFFFF);
		guiGraphics.method_25303(this.field_22793, "Select category", panelLeft + PANEL_PADDING, panelTop + 20, 0xFFA0A0A0);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
	}

	private void bsl$openPage(int targetPage) {
		this.field_22787.method_1507(new CategoryFilterSidebarScreen(this.parent, this.activeCategory, this.onSelect, targetPage));
	}

	private void bsl$selectAndClose(String category) {
		this.onSelect.accept(category == null ? "" : category);
		this.field_22787.method_1507(this.parent);
	}

	private List<String> bsl$buildOptions() {
		List<String> options = new ArrayList<>();
		options.add("");
		options.addAll(ServerMetadataStore.getKnownCategories());
		return options;
	}

	private int bsl$getPageSize() {
		int panelHeight = this.field_22790 - PANEL_MARGIN * 2;
		int listHeight = panelHeight - HEADER_HEIGHT - FOOTER_HEIGHT - 4;
		return Math.max(1, listHeight / (ROW_HEIGHT + ROW_GAP));
	}

	private String bsl$formatOption(String option) {
		String value = option == null || option.isBlank() ? "All" : option;
		if (value.length() > 22) {
			value = value.substring(0, 19) + "...";
		}
		if (option == null) {
			option = "";
		}
		boolean selected = option.equalsIgnoreCase(this.activeCategory) || (option.isBlank() && this.activeCategory.isBlank());
		return selected ? "> " + value : value;
	}
}
