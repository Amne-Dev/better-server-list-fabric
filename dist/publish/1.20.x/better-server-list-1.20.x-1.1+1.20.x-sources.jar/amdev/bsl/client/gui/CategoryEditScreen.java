package amdev.bsl.client.gui;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CategoryEditScreen extends class_437 {
	private final class_437 parent;
	private final Consumer<String> onSave;
	private final String initialValue;
	private class_342 categoryField;

	public CategoryEditScreen(class_437 parent, String initialValue, Consumer<String> onSave) {
		super(class_2561.method_43470("Edit Category"));
		this.parent = parent;
		this.initialValue = initialValue == null ? "" : initialValue;
		this.onSave = onSave;
	}

	@Override
	protected void method_25426() {
		int fieldWidth = Math.min(320, this.field_22789 - 40);
		int centerX = this.field_22789 / 2;
		int centerY = this.field_22790 / 2;

		this.categoryField = this.method_37063(
			new class_342(this.field_22793, centerX - fieldWidth / 2, centerY - 10, fieldWidth, 20, class_2561.method_43470("Category"))
		);
		this.categoryField.method_1880(32);
		this.categoryField.method_1852(this.initialValue);
		this.method_48265(this.categoryField);

		this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Save"), button -> this.bsl$saveAndClose()).method_46434(centerX - 155, centerY + 22, 100, 20).method_46431()
		);
		this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Clear"), button -> this.bsl$clearAndClose()).method_46434(centerX - 50, centerY + 22, 100, 20).method_46431()
		);
		this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Cancel"), button -> this.field_22787.method_1507(this.parent)).method_46434(centerX + 55, centerY + 22, 100, 20).method_46431()
		);
	}

	@Override
	public boolean method_25422() {
		return true;
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(this.parent);
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		guiGraphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xB0101010);
		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 34, 0xFFFFFFFF);
		guiGraphics.method_25300(this.field_22793, "Type any custom category name", this.field_22789 / 2, this.field_22790 / 2 - 22, 0xFFA0A0A0);
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
	}

	private void bsl$saveAndClose() {
		this.onSave.accept(this.categoryField.method_1882().trim());
		this.field_22787.method_1507(this.parent);
	}

	private void bsl$clearAndClose() {
		this.onSave.accept("");
		this.field_22787.method_1507(this.parent);
	}
}
