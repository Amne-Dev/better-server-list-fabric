package amdev.bsl.mixin.client;

import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin {
	@Inject(method = "init", at = @At("TAIL"))
	private void bsl$noop(CallbackInfo ci) {
		// Profile-specific overrides can provide behavior here.
	}
}
