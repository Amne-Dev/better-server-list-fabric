package amdev.bsl.mixin.client;

import java.util.List;
import net.minecraft.class_7843;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7843.class)
public interface FrameLayoutAccessor {
	@Accessor("children")
	List<?> bsl$getChildren();
}
