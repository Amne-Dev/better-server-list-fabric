package amdev.bsl.mixin.client;

import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_500.class)
public interface JoinMultiplayerScreenInvoker {
	@Invoker("refreshServerList")
	void bsl$refreshServerList();
}
