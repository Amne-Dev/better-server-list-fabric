package amdev.bsl.mixin.client;

import net.minecraft.class_7843;
import net.minecraft.class_8132;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8132.class)
public interface HeaderAndFooterLayoutAccessor {
	@Accessor("headerFrame")
	class_7843 bsl$getHeaderFrame();
}
