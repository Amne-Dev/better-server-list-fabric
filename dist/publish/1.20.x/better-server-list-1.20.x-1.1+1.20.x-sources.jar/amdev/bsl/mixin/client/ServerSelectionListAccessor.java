package amdev.bsl.mixin.client;

import java.util.List;
import net.minecraft.class_4267;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4267.class)
public interface ServerSelectionListAccessor {
	@Accessor("onlineServers")
	List<class_4267.class_4270> bsl$getOnlineServers();

	@Invoker("refreshEntries")
	void bsl$refreshEntries();
}
