package amdev.bsl.client.gui;

import amdev.bsl.client.PublicServerCatalog;
import amdev.bsl.client.ServerMetadataStore;
import amdev.bsl.client.ServerOrdering;
import amdev.bsl.mixin.client.JoinMultiplayerScreenInvoker;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;

public final class ServerBrowserScreen extends class_437 {
	private static final int PAGE_SIZE = 8;
	private static final int ROW_HEIGHT = 36;

	private final class_500 parent;
	private final List<PublicServerCatalog.Entry> allEntries = new ArrayList<>();
	private final List<PublicServerCatalog.Entry> filteredEntries = new ArrayList<>();
	private final List<class_4185> resultButtons = new ArrayList<>();
	private class_342 searchField;
	private class_4185 previousPageButton;
	private class_4185 nextPageButton;
	private class_4185 addButton;
	private class_4185 openWebsiteButton;
	private class_4185 refreshApiButton;
	private PublicServerCatalog.Entry selected;
	private int currentPage;
	private String statusMessage = "";
	private int buttonX;
	private int buttonWidth;
	private int listTop;
	private class_1799 loadingIcon;
	private boolean loadingLive;
	private CompletableFuture<PublicServerCatalog.LoadResult> liveLoadFuture;

	public ServerBrowserScreen(class_500 parent) {
		super(class_2561.method_43470("Find Servers"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		this.bsl$cancelLiveLoad();
		this.allEntries.clear();
		this.filteredEntries.clear();
		this.selected = null;
		this.currentPage = 0;
		this.loadingIcon = class_1799.field_8037;

		this.listTop = 46;
		this.buttonWidth = Math.min(this.field_22789 - 20, Math.max(575, this.field_22789 - 40));
		this.buttonX = (this.field_22789 - this.buttonWidth) / 2;

		this.searchField = this.method_37063(new class_342(this.field_22793, this.buttonX, 18, this.buttonWidth, 20, class_2561.method_43470("Search public servers")));
		this.searchField.method_1887("Search name, address, category, tags");
		this.searchField.method_25365(true);
		this.searchField.method_1863(value -> {
			this.currentPage = 0;
			this.bsl$refreshFilteredEntries();
		});

		this.resultButtons.clear();
		for (int i = 0; i < PAGE_SIZE; i++) {
			final int slot = i;
			class_4185 button = this.method_37063(
				this.bsl$makeButton(
					this.buttonX,
					this.listTop + i * ROW_HEIGHT,
					this.buttonWidth,
					ROW_HEIGHT - 2,
					class_2561.method_43473(),
					b -> this.bsl$selectFromSlot(slot)
				)
			);
			this.resultButtons.add(button);
		}

		int controlsY = this.field_22790 - 54;
		int prevX = this.buttonX;
		int nextX = prevX + 80;
		int addX = nextX + 80;
		int websiteX = addX + 115;
		int reloadX = websiteX + 115;
		int doneX = this.buttonX + this.buttonWidth - 75;

		this.previousPageButton = this.method_37063(this.bsl$makeButton(prevX, controlsY, 75, 20, class_2561.method_43470("< Prev"), b -> this.bsl$changePage(-1)));
		this.nextPageButton = this.method_37063(this.bsl$makeButton(nextX, controlsY, 75, 20, class_2561.method_43470("Next >"), b -> this.bsl$changePage(1)));
		this.addButton = this.method_37063(this.bsl$makeButton(addX, controlsY, 110, 20, class_2561.method_43470("Add Selected"), b -> this.bsl$addSelectedServer()));
		this.openWebsiteButton = this.method_37063(this.bsl$makeButton(websiteX, controlsY, 110, 20, class_2561.method_43470("Open Website"), b -> this.bsl$openSelectedWebsite()));
		this.refreshApiButton = this.method_37063(this.bsl$makeButton(reloadX, controlsY, 100, 20, class_2561.method_43470("Reload API"), b -> this.bsl$loadLiveCatalog(true)));
		this.method_37063(this.bsl$makeButton(doneX, controlsY, 75, 20, class_2561.method_43470("Done"), b -> this.field_22787.method_1507(this.parent)));

		this.loadingLive = true;
		this.statusMessage = "Loading live server catalog...";
		this.bsl$refreshFilteredEntries();
		this.bsl$loadLiveCatalog(false);
	}

	@Override
	public void method_25419() {
		this.bsl$cancelLiveLoad();
		this.field_22787.method_1507(this.parent);
	}

	@Override
	public void method_25394(class_4587 poseStack, int mouseX, int mouseY, float partialTick) {
		this.method_25294(poseStack, 0, 0, this.field_22789, this.field_22790, 0xB0101010);
		super.method_25394(poseStack, mouseX, mouseY, partialTick);

		method_27534(poseStack, this.field_22793, this.field_22785, this.field_22789 / 2, 6, 0xFFFFFFFF);
		method_25303(poseStack, this.field_22793, "Results: " + this.filteredEntries.size(), 10, this.field_22790 - 76, 0xFFA0A0A0);
		if (!this.statusMessage.isEmpty()) {
			method_25303(poseStack, this.field_22793, this.statusMessage, 10, this.field_22790 - 66, 0xFF80FF80);
		}

		if (this.loadingLive) {
			this.bsl$renderLoadingIndicator(poseStack);
		} else {
			this.bsl$renderRows(poseStack);
		}
	}

	private void bsl$renderRows(class_4587 poseStack) {
		int pageStart = this.currentPage * PAGE_SIZE;
		for (int i = 0; i < PAGE_SIZE; i++) {
			int index = pageStart + i;
			if (index < 0 || index >= this.filteredEntries.size()) {
				continue;
			}

			PublicServerCatalog.Entry entry = this.filteredEntries.get(index);
			int rowX = this.buttonX;
			int rowY = this.listTop + i * ROW_HEIGHT;

			if (entry.equals(this.selected)) {
				this.method_25294(poseStack, rowX - 1, rowY - 1, rowX + this.buttonWidth + 1, rowY + ROW_HEIGHT - 1, 0x40FFD67A);
				this.method_25294(poseStack, rowX - 1, rowY - 1, rowX + this.buttonWidth + 1, rowY, 0xFFFFD67A);
				this.method_25294(poseStack, rowX - 1, rowY + ROW_HEIGHT - 2, rowX + this.buttonWidth + 1, rowY + ROW_HEIGHT - 1, 0xFFFFD67A);
			}

			this.bsl$drawLogo(poseStack, rowX + 6, rowY + 8);
			method_25303(poseStack, this.field_22793, this.bsl$abbreviate(entry.name(), 38), rowX + 28, rowY + 6, 0xFFFFFFFF);
			method_25303(poseStack, this.field_22793, this.bsl$abbreviate(entry.address(), 45), rowX + 28, rowY + 18, 0xFF9FA7B0);

			String playersText = this.bsl$playersText(entry);
			int playersColor = entry.players() > 0 ? 0xFF9DE27A : 0xFFA0A0A0;
			method_25303(poseStack, this.field_22793, playersText, rowX + this.buttonWidth - 120, rowY + 12, playersColor);
		}
	}

	private void bsl$renderLoadingIndicator(class_4587 poseStack) {
		float wave = (float) Math.sin((class_156.method_658() % 1600L) / 1600.0 * Math.PI * 2.0);
		float pulse = (wave + 1.0f) * 0.5f;
		int iconX = this.field_22789 / 2 - 8;
		int iconY = this.listTop + PAGE_SIZE * ROW_HEIGHT / 2 - 8;

		class_1799 icon = this.bsl$getLoadingIcon();
		if (!icon.method_7960()) {
			this.field_22788.method_4023(poseStack, icon, iconX, iconY);
		} else {
			this.bsl$renderFallbackIcon(poseStack, iconX, iconY, true);
		}

		int darkAlpha = ((int) ((1.0f - pulse) * 120.0f)) << 24;
		int lightAlpha = ((int) (pulse * 70.0f)) << 24;
		this.method_25294(poseStack, iconX, iconY, iconX + 16, iconY + 16, darkAlpha);
		this.method_25294(poseStack, iconX, iconY, iconX + 16, iconY + 16, lightAlpha | 0x00FFFFFF);

		int textAlpha = ((int) (140 + pulse * 115.0f)) << 24;
		method_25300(poseStack, this.field_22793, "Loading...", this.field_22789 / 2, iconY + 24, textAlpha | 0xD8C8FF);
	}

	private void bsl$drawLogo(class_4587 poseStack, int x, int y) {
		class_1799 icon = this.bsl$getLoadingIcon();
		if (!icon.method_7960()) {
			this.field_22788.method_4023(poseStack, icon, x, y);
		} else {
			this.bsl$renderFallbackIcon(poseStack, x, y, false);
		}
	}

	private class_1799 bsl$getLoadingIcon() {
		if (this.loadingIcon != null && !this.loadingIcon.method_7960()) {
			return this.loadingIcon;
		}
		try {
			this.loadingIcon = new class_1799(class_1802.field_27063);
			return this.loadingIcon;
		} catch (Exception ignored) {
			return class_1799.field_8037;
		}
	}

	private class_4185 bsl$makeButton(int x, int y, int width, int height, class_2561 label, class_4185.class_4241 onPress) {
		return class_4185.method_46430(label, onPress).method_46434(x, y, width, height).method_46431();
	}

	private void bsl$renderFallbackIcon(class_4587 poseStack, int x, int y, boolean loading) {
		int fillColor = loading ? 0xFF6C5D92 : 0xFF4B4F57;
		int borderColor = loading ? 0xFFD8C8FF : 0xFF9AA0AA;
		this.method_25294(poseStack, x, y, x + 16, y + 16, fillColor);
		this.method_25294(poseStack, x, y, x + 16, y + 1, borderColor);
		this.method_25294(poseStack, x, y + 15, x + 16, y + 16, borderColor);
		this.method_25294(poseStack, x, y, x + 1, y + 16, borderColor);
		this.method_25294(poseStack, x + 15, y, x + 16, y + 16, borderColor);
	}

	private void bsl$refreshFilteredEntries() {
		String query = this.searchField == null ? "" : this.searchField.method_1882().trim().toLowerCase(Locale.ROOT);

		this.filteredEntries.clear();
		for (PublicServerCatalog.Entry entry : this.allEntries) {
			if (this.bsl$matchesQuery(entry, query)) {
				this.filteredEntries.add(entry);
			}
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		if (this.currentPage > maxPage) {
			this.currentPage = maxPage;
		}
		if (this.selected != null && !this.filteredEntries.contains(this.selected)) {
			this.selected = null;
		}

		this.bsl$refreshResultButtons();
		this.bsl$refreshActionButtons();
	}

	private void bsl$loadLiveCatalog(boolean forceRefresh) {
		this.bsl$cancelLiveLoad();

		if (!forceRefresh) {
			PublicServerCatalog.LoadResult cached = PublicServerCatalog.getSessionCachedResult();
			if (cached != null) {
				this.loadingLive = false;
				this.statusMessage = cached.fromLiveApi()
					? "Loaded " + cached.entries().size() + " servers from session cache."
					: "Using cached bundled catalog from this session.";
				this.allEntries.clear();
				this.allEntries.addAll(cached.entries());
				this.filteredEntries.clear();
				this.selected = null;
				this.currentPage = 0;
				this.bsl$refreshFilteredEntries();
				return;
			}
		}

		if (this.refreshApiButton != null) {
			this.refreshApiButton.field_22763 = false;
		}
		this.loadingLive = true;
		this.statusMessage = forceRefresh ? "Reloading live server catalog..." : "Loading live server catalog...";
		this.allEntries.clear();
		this.filteredEntries.clear();
		this.selected = null;
		this.currentPage = 0;
		this.bsl$refreshFilteredEntries();

		this.liveLoadFuture = forceRefresh
			? PublicServerCatalog.reloadPreferredAsync(this.field_22787.method_1478())
			: PublicServerCatalog.loadPreferredAsync(this.field_22787.method_1478());
		this.liveLoadFuture.whenComplete((result, throwable) -> this.field_22787.execute(() -> {
			if (this.field_22787 == null || this.field_22787.field_1755 != this) {
				return;
			}

			this.loadingLive = false;
			if (this.refreshApiButton != null) {
				this.refreshApiButton.field_22763 = true;
			}

			PublicServerCatalog.LoadResult safeResult;
			if (throwable != null || result == null || result.entries() == null) {
				safeResult = new PublicServerCatalog.LoadResult(PublicServerCatalog.loadBundled(this.field_22787.method_1478()), false);
				this.statusMessage = "Live API unavailable. Showing bundled catalog.";
			} else {
				safeResult = result;
				if (safeResult.fromLiveApi()) {
					this.statusMessage = "Loaded " + safeResult.entries().size() + " servers from live API.";
				} else {
					this.statusMessage = "Live API unavailable. Showing bundled catalog.";
				}
			}

			this.allEntries.clear();
			this.allEntries.addAll(safeResult.entries());
			this.currentPage = 0;
			this.selected = null;
			this.bsl$refreshFilteredEntries();
		}));
	}

	private void bsl$cancelLiveLoad() {
		if (this.liveLoadFuture != null) {
			this.liveLoadFuture.cancel(true);
			this.liveLoadFuture = null;
		}
	}

	private void bsl$refreshResultButtons() {
		if (this.loadingLive) {
			for (class_4185 button : this.resultButtons) {
				button.field_22764 = false;
				button.field_22763 = false;
			}
			return;
		}

		int pageStart = this.currentPage * PAGE_SIZE;
		for (int i = 0; i < this.resultButtons.size(); i++) {
			class_4185 button = this.resultButtons.get(i);
			int index = pageStart + i;
			if (index < this.filteredEntries.size()) {
				button.field_22764 = true;
				button.field_22763 = true;
				button.method_25355(class_2561.method_43473());
			} else {
				button.field_22764 = false;
				button.field_22763 = false;
			}
		}
	}

	private void bsl$refreshActionButtons() {
		if (this.loadingLive) {
			this.previousPageButton.field_22763 = false;
			this.nextPageButton.field_22763 = false;
			this.addButton.field_22763 = false;
			this.openWebsiteButton.field_22763 = false;
			return;
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		this.previousPageButton.field_22763 = this.currentPage > 0;
		this.nextPageButton.field_22763 = this.currentPage < maxPage;

		if (this.selected == null) {
			this.addButton.field_22763 = false;
			this.openWebsiteButton.field_22763 = false;
			return;
		}

		this.addButton.field_22763 = true;
		this.openWebsiteButton.field_22763 = !this.selected.website().isEmpty();
	}

	private void bsl$selectFromSlot(int slot) {
		if (this.loadingLive) {
			return;
		}

		int index = this.currentPage * PAGE_SIZE + slot;
		if (index < 0 || index >= this.filteredEntries.size()) {
			return;
		}
		this.selected = this.filteredEntries.get(index);
		this.statusMessage = "";
		this.bsl$refreshActionButtons();
	}

	private void bsl$changePage(int delta) {
		if (this.loadingLive) {
			return;
		}

		int maxPage = Math.max(0, (this.filteredEntries.size() - 1) / PAGE_SIZE);
		this.currentPage = Math.max(0, Math.min(maxPage, this.currentPage + delta));
		this.bsl$refreshResultButtons();
		this.bsl$refreshActionButtons();
	}

	private void bsl$addSelectedServer() {
		if (this.selected == null) {
			return;
		}

		class_641 serverList = this.parent.method_2529();
		if (this.bsl$containsServer(serverList, this.selected.address())) {
			this.statusMessage = "Server already exists in your list.";
			return;
		}

		class_642 serverData = new class_642(this.selected.name(), this.selected.address(), false);
		serverList.method_2988(serverData, false);
		if (ServerMetadataStore.getCategory(serverData.field_3761).isEmpty() && !this.selected.category().isEmpty()) {
			ServerMetadataStore.setCategory(serverData.field_3761, this.selected.category());
		}
		ServerOrdering.reorder(serverList);
		serverList.method_2987();
		((JoinMultiplayerScreenInvoker) this.parent).bsl$refreshServerList();

		this.statusMessage = "Added " + this.selected.name() + ".";
	}

	private void bsl$openSelectedWebsite() {
		if (this.selected == null || this.selected.website().isEmpty()) {
			return;
		}

		this.field_22787.method_1507(new class_407(open -> {
			if (open) {
				class_156.method_668().method_670(this.selected.website());
			}
			this.field_22787.method_1507(this);
		}, this.selected.website(), true));
	}

	private boolean bsl$containsServer(class_641 serverList, String address) {
		if (serverList == null || address == null || address.trim().isEmpty()) {
			return false;
		}
		String normalized = address.trim().toLowerCase(Locale.ROOT);
		for (int i = 0; i < serverList.method_2984(); i++) {
			class_642 existing = serverList.method_2982(i);
			if (existing != null && existing.field_3761 != null && normalized.equals(existing.field_3761.trim().toLowerCase(Locale.ROOT))) {
				return true;
			}
		}
		return false;
	}

	private boolean bsl$matchesQuery(PublicServerCatalog.Entry entry, String query) {
		if (query.isEmpty()) {
			return true;
		}

		String searchable = entry.searchableText().toLowerCase(Locale.ROOT);
		String[] terms = query.split("\\s+");
		for (String term : terms) {
			if (!term.isEmpty() && !searchable.contains(term)) {
				return false;
			}
		}
		return true;
	}

	private String bsl$playersText(PublicServerCatalog.Entry entry) {
		if (entry.players() >= 0 && entry.maxPlayers() > 0) {
			return "Players: " + entry.players() + "/" + entry.maxPlayers();
		}
		if (entry.players() >= 0) {
			return "Players: " + entry.players();
		}
		return "Players: --";
	}

	private String bsl$abbreviate(String value, int maxLength) {
		if (value.length() <= maxLength) {
			return value;
		}
		return value.substring(0, maxLength - 3) + "...";
	}
}


