package amdev.bsl.mixin.client;

import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_500.class)
public interface HeaderAndFooterLayoutAccessor {
}
