package amdev.bsl.mixin.client;

import amdev.bsl.client.ServerMetadataStore;
import amdev.bsl.client.ServerOrdering;
import amdev.bsl.client.gui.CategoryFilterSidebarScreen;
import amdev.bsl.client.gui.CategoryEditScreen;
import amdev.bsl.client.gui.ServerBrowserScreen;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_500.class)
public abstract class JoinMultiplayerScreenMixin extends class_437 {
	protected JoinMultiplayerScreenMixin(class_2561 title) {
		super(title);
	}

	@Shadow
	protected class_4267 serverSelectionList;

	@Shadow
	private class_641 servers;

	@Shadow
	protected abstract void onSelectedChange();

	@Unique
	private class_4185 bslFavoriteButton;

	@Unique
	private class_4185 bslCategoryButton;

	@Unique
	private class_4185 bslFindServersButton;

	@Unique
	private class_342 bslSearchBox;

	@Unique
	private class_4185 bslCategoryFilterButton;

	@Unique
	private String bslActiveCategoryFilter = "";

	@Unique
	private final List<class_4185> bslCategoryDropdownButtons = new ArrayList<>();

	@Unique
	private boolean bslCategoryDropdownOpen;

	@Unique
	private int bslCategoryFilterX;

	@Unique
	private int bslCategoryFilterY;

	@Unique
	private int bslCategoryFilterWidth = 120;

	@Unique
	private int bslLastLayoutWidth = -1;

	@Unique
	private int bslLastLayoutHeight = -1;

	@Unique
	private static final int BSL_CONTROL_HEIGHT = 20;

	@Unique
	private static final int BSL_CONTROL_GAP = 4;

	@Unique
	private static final int BSL_TOP_Y = 36;

	@Unique
	private static final int BSL_LIST_TOP_GAP = 8;

	@Unique
	private static final int BSL_LIST_BOTTOM_PADDING = 64;

	@Inject(method = "init", at = @At("TAIL"))
	private void bsl$addCategoryButtons(CallbackInfo ci) {
		this.bslSearchBox = this.method_37063(new class_342(this.field_22787.field_1772, 8, 8, 180, BSL_CONTROL_HEIGHT, class_2561.method_43470("Search")));
		this.bslSearchBox.method_47404(class_2561.method_43470("Search servers"));
		this.bslSearchBox.method_1863(value -> this.bsl$applyServerView(null));

		this.bslFavoriteButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Fav"), button -> this.bsl$toggleFavorite()).method_46434(8, 8, 100, BSL_CONTROL_HEIGHT).method_46431()
		);
		this.bslCategoryButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Category"), button -> this.bsl$openCategoryEditor()).method_46434(8, 8, 120, BSL_CONTROL_HEIGHT).method_46431()
		);
		this.bslFindServersButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Find"), button -> this.bsl$openServerBrowser()).method_46434(8, 8, 110, BSL_CONTROL_HEIGHT).method_46431()
		);
		this.bslCategoryFilterButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Show: All"), button -> this.bsl$toggleCategoryDropdown()).method_46434(8, 8, 120, BSL_CONTROL_HEIGHT).method_46431()
		);
		this.bsl$layoutWidgets();
		this.bsl$applyServerView(null);
	}

	@Inject(method = "tick", at = @At("TAIL"))
	private void bsl$ensureLayoutOnResize(CallbackInfo ci) {
		if (this.field_22789 != this.bslLastLayoutWidth || this.field_22790 != this.bslLastLayoutHeight) {
			this.bsl$layoutWidgets();
		}
	}

	@Inject(method = "refreshServerList", at = @At("TAIL"))
	private void bsl$sortOnRefresh(CallbackInfo ci) {
		this.bsl$applyServerView(null);
	}

	@Inject(method = "onSelectedChange", at = @At("TAIL"))
	private void bsl$updateButtonsOnSelection(CallbackInfo ci) {
		this.bsl$updateButtons();
	}

	@Inject(method = "removed", at = @At("TAIL"))
	private void bsl$saveStore(CallbackInfo ci) {
		this.bsl$closeCategoryDropdown();
		ServerMetadataStore.save();
	}
	@Unique
	private void bsl$toggleFavorite() {
		class_642 selected = this.bsl$getSelectedServerData();
		if (selected == null) {
			return;
		}

		String key = selected.field_3761;
		boolean nextValue = !ServerMetadataStore.isFavorite(key);
		ServerMetadataStore.setFavorite(key, nextValue);
		this.bsl$applyServerView(key);
	}

	@Unique
	private void bsl$openCategoryEditor() {
		class_642 selected = this.bsl$getSelectedServerData();
		if (selected == null) {
			return;
		}

		String key = selected.field_3761;
		String current = ServerMetadataStore.getCategory(key);
		this.field_22787.method_1507(new CategoryEditScreen((class_500) (Object) this, current, next -> {
			ServerMetadataStore.setCategory(key, next);
			if (!this.bslActiveCategoryFilter.isBlank() && !ServerMetadataStore.getKnownCategories().contains(this.bslActiveCategoryFilter)) {
				this.bslActiveCategoryFilter = "";
			}
			this.bsl$applyServerView(key);
		}));
	}

	@Unique
	private void bsl$openServerBrowser() {
		this.bsl$closeCategoryDropdown();
		this.field_22787.method_1507(new ServerBrowserScreen((class_500) (Object) this));
	}

	@Unique
	public void bsl$applyServerView(String preferredAddress) {
		if (this.serverSelectionList == null || this.servers == null) {
			return;
		}

		String selectedAddress = preferredAddress;
		if (selectedAddress == null) {
			class_642 selected = this.bsl$getSelectedServerData();
			if (selected != null) {
				selectedAddress = selected.field_3761;
			}
		}

		ServerOrdering.reorder(this.servers);
		this.serverSelectionList.method_20125(this.servers);
		this.bsl$filterEntries();

		this.bsl$restoreSelection(selectedAddress);
		this.onSelectedChange();
		this.bsl$updateButtons();
	}

	@Unique
	private void bsl$filterEntries() {
		String query = this.bsl$getSearchQuery();
		String categoryFilter = this.bslActiveCategoryFilter;

		ServerSelectionListAccessor accessor = (ServerSelectionListAccessor) this.serverSelectionList;
		List<class_4267.class_4270> onlineServers = accessor.bsl$getOnlineServers();
		onlineServers.removeIf(entry -> {
			class_642 data = entry.method_20133();
			return !this.bsl$matchesSearch(data, query) || !this.bsl$matchesCategory(data, categoryFilter);
		});
		accessor.bsl$refreshEntries();
	}

	@Unique
	private void bsl$restoreSelection(String serverAddress) {
		if (serverAddress != null) {
			for (class_4267.class_504 entry : this.serverSelectionList.method_25396()) {
				if (!(entry instanceof class_4267.class_4270 onlineServerEntry)) {
					continue;
				}
				class_642 data = onlineServerEntry.method_20133();
				if (data != null && serverAddress.equalsIgnoreCase(data.field_3761)) {
					this.serverSelectionList.method_20122(entry);
					break;
				}
			}
		}
	}

	@Unique
	private void bsl$updateButtons() {
		if (this.bslFavoriteButton == null || this.bslCategoryButton == null || this.bslFindServersButton == null || this.bslCategoryFilterButton == null) {
			return;
		}

		class_642 selected = this.bsl$getSelectedServerData();
		boolean hasSelection = selected != null;
		this.bslFavoriteButton.field_22763 = hasSelection;
		this.bslCategoryButton.field_22763 = hasSelection;

		if (!hasSelection) {
			this.bslFavoriteButton.method_25355(class_2561.method_43470("Fav"));
			this.bslCategoryButton.method_25355(class_2561.method_43470("Category"));
			this.bslFindServersButton.field_22763 = true;
			this.bsl$updateCategoryFilterButton();
			return;
		}

		boolean favorite = ServerMetadataStore.isFavorite(selected.field_3761);
		this.bslFavoriteButton.method_25355(class_2561.method_43470(favorite ? "Unfav" : "Fav"));
		this.bslCategoryButton.method_25355(class_2561.method_43470("Category"));
		this.bslFindServersButton.field_22763 = true;
		this.bsl$updateCategoryFilterButton();
	}

	@Unique
	private String bsl$getSearchQuery() {
		if (this.bslSearchBox == null) {
			return "";
		}
		return this.bslSearchBox.method_1882().trim().toLowerCase(Locale.ROOT);
	}

	@Unique
	private boolean bsl$matchesSearch(class_642 serverData, String query) {
		if (serverData == null) {
			return false;
		}
		if (query.isBlank()) {
			return true;
		}

		String category = ServerMetadataStore.getCategory(serverData.field_3761);
		boolean favorite = ServerMetadataStore.isFavorite(serverData.field_3761);
		String haystack = (
			(serverData.field_3752 == null ? "" : serverData.field_3752) + " " +
			(serverData.field_3761 == null ? "" : serverData.field_3761) + " " +
			category + " " +
			(favorite ? "favorite fav starred" : "")
		).toLowerCase(Locale.ROOT);

		String[] terms = query.split("\\s+");
		for (String term : terms) {
			if (!term.isEmpty() && !haystack.contains(term)) {
				return false;
			}
		}
		return true;
	}

	@Unique
	private boolean bsl$matchesCategory(class_642 serverData, String categoryFilter) {
		if (serverData == null) {
			return false;
		}
		if (categoryFilter == null || categoryFilter.isBlank()) {
			return true;
		}
		return categoryFilter.equalsIgnoreCase(ServerMetadataStore.getCategory(serverData.field_3761));
	}

	@Unique
	private void bsl$toggleCategoryDropdown() {
		this.bsl$closeCategoryDropdown();
		this.field_22787.method_1507(new CategoryFilterSidebarScreen((class_500) (Object) this, this.bslActiveCategoryFilter, category -> {
			this.bslActiveCategoryFilter = category == null ? "" : category;
			
		}));
	}

	@Unique
	private void bsl$updateCategoryFilterButton() {
		if (this.bslCategoryFilterButton == null) {
			return;
		}
		String label = this.bslActiveCategoryFilter.isBlank() ? "All" : this.bsl$abbreviate(this.bslActiveCategoryFilter, 8);
		this.bslCategoryFilterButton.method_25355(class_2561.method_43470("Show: " + label + " v"));
	}

	@Unique
	private void bsl$openCategoryDropdown() {
		this.bsl$closeCategoryDropdown();

		List<String> options = new ArrayList<>();
		options.add("");
		options.addAll(ServerMetadataStore.getKnownCategories());

		int y = Math.max(8, this.bslCategoryFilterY - options.size() * 20);
		for (String option : options) {
			String label = option.isBlank() ? "All" : this.bsl$abbreviate(option, 16);
			class_4185 optionButton = this.method_37063(
				class_4185.method_46430(class_2561.method_43470(label), button -> this.bsl$setCategoryFilter(option))
					.method_46434(this.bslCategoryFilterX, y, this.bslCategoryFilterWidth, 20)
					.method_46431()
			);
			this.bslCategoryDropdownButtons.add(optionButton);
			y += 20;
		}

		this.bslCategoryDropdownOpen = true;
	}

	@Unique
	private void bsl$closeCategoryDropdown() {
		if (this.bslCategoryDropdownButtons.isEmpty()) {
			this.bslCategoryDropdownOpen = false;
			return;
		}

		for (class_4185 button : this.bslCategoryDropdownButtons) {
			this.method_37066(button);
		}
		this.bslCategoryDropdownButtons.clear();
		this.bslCategoryDropdownOpen = false;
	}

	@Unique
	private void bsl$setCategoryFilter(String category) {
		this.bslActiveCategoryFilter = category == null ? "" : category;
		this.bsl$closeCategoryDropdown();
		this.bsl$applyServerView(null);
	}

	@Unique
	private void bsl$layoutWidgets() {
		if (this.bslSearchBox == null || this.bslFavoriteButton == null || this.bslCategoryButton == null || this.bslFindServersButton == null || this.bslCategoryFilterButton == null) {
			return;
		}

		int margin = 8;
		int availableWidth = Math.max(220, this.field_22789 - margin * 2);
		int y = BSL_TOP_Y;
		int favoriteWidth = 84;
		int categoryWidth = 104;
		int findWidth = 84;
		int filterWidth = 104;
		int buttonsTotalWidth = favoriteWidth + categoryWidth + findWidth + filterWidth + BSL_CONTROL_GAP * 3;
		int minOneRowSearch = 180;

		if (availableWidth >= buttonsTotalWidth + BSL_CONTROL_GAP + minOneRowSearch) {
			int searchWidth = availableWidth - buttonsTotalWidth - BSL_CONTROL_GAP;
			int buttonX = margin + searchWidth + BSL_CONTROL_GAP;

			this.bsl$setBounds(this.bslSearchBox, margin, y, searchWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslFavoriteButton, buttonX, y, favoriteWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslCategoryButton, buttonX + favoriteWidth + BSL_CONTROL_GAP, y, categoryWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslFindServersButton, buttonX + favoriteWidth + categoryWidth + BSL_CONTROL_GAP * 2, y, findWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslCategoryFilterButton, buttonX + favoriteWidth + categoryWidth + findWidth + BSL_CONTROL_GAP * 3, y, filterWidth, BSL_CONTROL_HEIGHT);
		} else if (availableWidth >= 320) {
			int secondRowY = y + BSL_CONTROL_HEIGHT + BSL_CONTROL_GAP;
			int compactButtonWidth = Math.max(72, (availableWidth - BSL_CONTROL_GAP * 3) / 4);

			this.bsl$setBounds(this.bslSearchBox, margin, y, availableWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslFavoriteButton, margin, secondRowY, compactButtonWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslCategoryButton, margin + compactButtonWidth + BSL_CONTROL_GAP, secondRowY, compactButtonWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslFindServersButton, margin + compactButtonWidth * 2 + BSL_CONTROL_GAP * 2, secondRowY, compactButtonWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslCategoryFilterButton, margin + compactButtonWidth * 3 + BSL_CONTROL_GAP * 3, secondRowY, compactButtonWidth, BSL_CONTROL_HEIGHT);
		} else {
			int secondRowY = y + BSL_CONTROL_HEIGHT + BSL_CONTROL_GAP;
			int thirdRowY = secondRowY + BSL_CONTROL_HEIGHT + BSL_CONTROL_GAP;
			int twoColWidth = Math.max(104, (availableWidth - BSL_CONTROL_GAP) / 2);

			this.bsl$setBounds(this.bslSearchBox, margin, y, availableWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslFavoriteButton, margin, secondRowY, twoColWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslCategoryButton, margin + twoColWidth + BSL_CONTROL_GAP, secondRowY, twoColWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslFindServersButton, margin, thirdRowY, twoColWidth, BSL_CONTROL_HEIGHT);
			this.bsl$setBounds(this.bslCategoryFilterButton, margin + twoColWidth + BSL_CONTROL_GAP, thirdRowY, twoColWidth, BSL_CONTROL_HEIGHT);
		}

		this.bslCategoryFilterX = this.bslCategoryFilterButton.method_46426();
		this.bslCategoryFilterY = this.bslCategoryFilterButton.method_46427() + BSL_CONTROL_HEIGHT;
		this.bslCategoryFilterWidth = this.bslCategoryFilterButton.method_25368();
		this.bslLastLayoutWidth = this.field_22789;
		this.bslLastLayoutHeight = this.field_22790;
		this.bsl$closeCategoryDropdown();
		this.bsl$layoutServerListArea();
	}

	@Unique
	private void bsl$setBounds(class_339 widget, int x, int y, int width, int height) {
		widget.method_25358(width);
		widget.method_46421(x);
		widget.method_46419(y);
	}

	@Unique
	private void bsl$layoutServerListArea() {
		if (this.serverSelectionList == null) {
			return;
		}

		int controlsBottom = Math.max(
			Math.max(this.bslSearchBox.method_46427() + this.bslSearchBox.method_25364(), this.bslFavoriteButton.method_46427() + this.bslFavoriteButton.method_25364()),
			Math.max(
				this.bslCategoryButton.method_46427() + this.bslCategoryButton.method_25364(),
				Math.max(this.bslFindServersButton.method_46427() + this.bslFindServersButton.method_25364(), this.bslCategoryFilterButton.method_46427() + this.bslCategoryFilterButton.method_25364())
			)
		);

		int top = Math.max(48, controlsBottom + BSL_LIST_TOP_GAP);
		int contentHeight = Math.max(80, this.field_22790 - BSL_LIST_BOTTOM_PADDING - top);
		this.serverSelectionList.method_25323(this.field_22789, this.field_22790, top, this.field_22790 - BSL_LIST_BOTTOM_PADDING);
	}

	@Unique
	private String bsl$abbreviate(String value, int maxLength) {
		if (value.length() <= maxLength) {
			return value;
		}
		return value.substring(0, maxLength - 3) + "...";
	}

	@Unique
	private class_642 bsl$getSelectedServerData() {
		class_4267.class_504 selectedEntry = this.serverSelectionList.method_25334();
		if (selectedEntry instanceof class_4267.class_4270 onlineServerEntry) {
			return onlineServerEntry.method_20133();
		}
		return null;
	}
}


